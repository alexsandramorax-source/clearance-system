$ErrorActionPreference = 'Stop'

Write-Host 'Configure Gmail SMTP for the School Clearance System.'
Write-Host 'Use a Google App Password, not your regular Google account password.'
Write-Host 'App Passwords require 2-Step Verification on your Google account.'

$email = (Read-Host 'Gmail address to send from').Trim()
try {
    $parsedEmail = New-Object -TypeName System.Net.Mail.MailAddress -ArgumentList $email
    if ($parsedEmail.Address -ne $email) {
        throw 'Enter a valid email address.'
    }
} catch {
    Write-Error 'Enter a valid Gmail address.'
    exit 1
}

$securePassword = Read-Host 'Google App Password (input hidden)' -AsSecureString
$appPassword = [System.Net.NetworkCredential]::new('', $securePassword).Password -replace '\s', ''
if ($appPassword.Length -ne 16) {
    $appPassword = $null
    Write-Error 'A Google App Password must contain 16 characters. Create one in your Google Account and run this setup again.'
    exit 1
}

$settings = @{
    SCHOOL_CLEARANCE_SMTP_HOST = 'smtp.gmail.com'
    SCHOOL_CLEARANCE_SMTP_PORT = '587'
    SCHOOL_CLEARANCE_SMTP_CRYPTO = 'tls'
    SCHOOL_CLEARANCE_SMTP_USER = $email
    SCHOOL_CLEARANCE_SMTP_PASS = $appPassword
    SCHOOL_CLEARANCE_FROM_EMAIL = $email
}

foreach ($name in $settings.Keys) {
    [Environment]::SetEnvironmentVariable($name, $settings[$name], 'User')
}

$appPassword = $null
$securePassword.Dispose()

Write-Host ''
Write-Host 'Gmail SMTP settings are saved for your Windows user and are not written into the project.'
Write-Host 'Close the XAMPP Control Panel completely, open it again, then restart Apache.'
Write-Host 'If Apache still reports SMTP is not configured, sign out of Windows and sign back in before reopening XAMPP.'
