<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($admin_page_title, ENT_QUOTES, 'UTF-8'); ?> | School Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>?v=<?= filemtime(FCPATH . 'assets/css/style.css'); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css">
</head>
<body class="admin-page">
<header class="app-topbar">
    <button class="app-menu-toggle" type="button" aria-label="Toggle navigation" aria-expanded="true">
        <span></span><span></span><span></span>
    </button>
    <a class="app-brand" href="<?= base_url('admin/dashboard'); ?>">School Clearance</a>
    <form class="app-logout-form" method="post" action="<?= base_url('logout'); ?>"
          onsubmit="return confirm('Are you sure you want to log out?');">
        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
               value="<?= $this->security->get_csrf_hash(); ?>">
        <button class="app-logout" type="submit">Log out</button>
    </form>
</header>

<nav class="app-sidebar" aria-label="Administrator navigation">
    <a class="<?= $admin_section === 'dashboard' ? 'is-active' : ''; ?>" href="<?= base_url('admin/dashboard'); ?>" aria-label="Dashboard" title="Dashboard">
        <span aria-hidden="true">▦</span>
        <span class="nav-label">Dashboard</span>
    </a>
    <a class="<?= $admin_section === 'requests' ? 'is-active' : ''; ?>" href="<?= base_url('admin/requests'); ?>" aria-label="Clearance requests" title="Clearance requests">
        <span aria-hidden="true">▤</span>
        <span class="nav-label">Clearance Requests</span>
    </a>
    <a class="<?= $admin_section === 'students' ? 'is-active' : ''; ?>" href="<?= base_url('admin/students'); ?>" aria-label="Student accounts" title="Student accounts">
        <span aria-hidden="true">♙</span>
        <span class="nav-label">Student Accounts</span>
    </a>
    <a class="<?= $admin_section === 'admins' ? 'is-active' : ''; ?>" href="<?= base_url('admin/admins'); ?>" aria-label="Create admin account" title="Create admin account">
        <span aria-hidden="true">＋</span>
        <span class="nav-label">Manage Admins</span>
    </a>
    <a class="<?= $admin_section === 'import' ? 'is-active' : ''; ?>" href="<?= base_url('admin/import-students'); ?>" aria-label="Import students" title="Import students">
        <span aria-hidden="true">⇧</span>
        <span class="nav-label">Import Students</span>
    </a>
    <a class="<?= $admin_section === 'email' ? 'is-active' : ''; ?>" href="<?= base_url('admin/email-students'); ?>" aria-label="Email students" title="Email students">
        <span aria-hidden="true">✉</span>
        <span class="nav-label">Email Students</span>
    </a>
</nav>

<main class="app-main">
    <div class="app-content admin-content">
        <div class="admin-heading">
            <div>
                <h1 class="app-page-heading"><?= htmlspecialchars($admin_page_title, ENT_QUOTES, 'UTF-8'); ?></h1>
                <p class="app-subheading"><?= htmlspecialchars($admin_page_description, ENT_QUOTES, 'UTF-8'); ?></p>
            </div>
            <span class="admin-role-badge">ADMIN</span>
        </div>

        <?php if ($admin_section === 'import'): ?>
        <details class="admin-create-panel" id="import-students" open>
            <summary class="admin-create-summary">
                <span>
                    <strong>Import Student Accounts</strong>
                    <small>Import validated student records from an XLSX or CSV spreadsheet.</small>
                </span>
                <span class="admin-create-icon" aria-hidden="true">+</span>
            </summary>
            <form method="post" action="<?= base_url('admin/students/import'); ?>"
                  enctype="multipart/form-data" class="admin-create-form">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                       value="<?= $this->security->get_csrf_hash(); ?>">
                <p>
                    Start with the
                    <a class="btn btn-outline-primary btn-sm" href="<?= base_url('admin/students/template'); ?>">Download Excel Template (.xlsx)</a>
                    or the <a href="<?= base_url('assets/templates/student_import_template.csv'); ?>">CSV template</a>.
                    Fill one student per row with these columns, in order:
                    <code>student_id, first_name, last_name, email, password, course, year_level, contact_number, address</code>.
                    Use year levels <code>1st Year</code> through <code>4th Year</code>. When updating an existing student, leave
                    the password blank to keep it unchanged; new students need a password of 8-72 characters, which is hashed before storage.
                    Re-upload the saved workbook to apply its changes. Matching uses Student ID, omitted students are left unchanged,
                    and duplicate IDs or emails reject the entire upload without saving any rows.
                </p>
                <p>Download the current student roster as an Excel workbook:
                    <a class="btn btn-outline-primary btn-sm" href="<?= base_url('admin/students/export'); ?>">Export Student Roster (.xlsx)</a>
                    Passwords are never included in exports; the password column is blank so existing passwords stay unchanged if you re-upload it.
                </p>
                <label class="form-label" for="student-import-file">Student spreadsheet (XLSX or CSV, max 10 MB)</label>
                <input id="student-import-file" type="file" name="student_file" class="form-control"
                       accept=".xlsx,.csv" required>
                <button type="submit" name="import_students" value="1" class="btn btn-primary mt-3">
                    Validate and Apply Spreadsheet Changes
                </button>
            </form>
        </details>
        <?php endif; ?>

        <?php if ($admin_section === 'email'): ?>
        <details class="admin-create-panel" id="email-students" open>
            <summary class="admin-create-summary">
                <span>
                    <strong>Email Students</strong>
                    <small>Send a private email to selected students or the full student roster, with an optional attachment.</small>
                </span>
                <span class="admin-create-icon" aria-hidden="true">+</span>
            </summary>
            <form method="post" action="<?= base_url('admin/students/email'); ?>"
                  enctype="multipart/form-data" class="admin-create-form">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                       value="<?= $this->security->get_csrf_hash(); ?>">
                <?php if (!$email_configured): ?>
                    <div class="alert alert-warning" role="status">
                        Gmail SMTP is not configured, so messages cannot be sent yet.
                        From the project folder, run <code>powershell -ExecutionPolicy Bypass -File .\configure-gmail-smtp.ps1</code>.
                        The setup asks for your Gmail address and a Google App Password (input is hidden); it does not
                        save credentials in the project. Then close and reopen the XAMPP Control Panel and restart Apache.
                        Google App Passwords require 2-Step Verification. Never use your regular account password here.
                    </div>
                <?php endif; ?>
                <p>
                    Students receive separate messages, so their email addresses are never exposed to one another.
                    <?= count($email_recipients); ?> student(s) have a valid email address. Each attachment is limited to 10 MB.
                </p>
                <div class="mb-3">
                    <label class="form-label" for="student-recipient-select">Selected students</label>
                    <select id="student-recipient-select" name="student_user_ids[]" class="form-select"
                            multiple size="7" <?= empty($email_recipients) ? 'disabled' : 'required'; ?>>
                        <?php foreach ($email_recipients as $recipient): ?>
                            <option value="<?= (int) $recipient->id; ?>">
                                <?= htmlspecialchars($recipient->last_name . ', ' . $recipient->first_name, ENT_QUOTES, 'UTF-8'); ?>
                                — <?= htmlspecialchars($recipient->student_id, ENT_QUOTES, 'UTF-8'); ?>
                                (<?= htmlspecialchars($recipient->email, ENT_QUOTES, 'UTF-8'); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-check mt-2">
                        <input id="email-all-students" name="send_to_all" value="1" type="checkbox" class="form-check-input"
                               <?= empty($email_recipients) ? 'disabled' : ''; ?>>
                        <label class="form-check-label" for="email-all-students">Email all <?= count($email_recipients); ?> students</label>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="student-email-subject">Subject</label>
                    <input id="student-email-subject" name="subject" type="text" class="form-control"
                           maxlength="150" required>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="student-email-message">Message</label>
                    <textarea id="student-email-message" name="message" class="form-control"
                              rows="6" maxlength="5000" required></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="student-email-attachment">Optional attachment</label>
                    <input id="student-email-attachment" name="email_attachment" type="file" class="form-control"
                           accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.jpg,.jpeg,.png">
                    <small class="form-text">Allowed: PDF, Word, Excel, CSV, TXT, JPG, or PNG (max 10 MB).</small>
                </div>
                <button type="submit" class="btn btn-primary mt-1"
                        <?= !$email_configured || empty($email_recipients) ? 'disabled' : ''; ?>>
                    Send Email
                </button>
            </form>
        </details>
        <?php endif; ?>

        <?php if ($admin_section === 'admins'): ?>
        <details class="admin-create-panel" id="create-admin" open>
            <summary class="admin-create-summary">
                <span>
                    <strong>Create Administrator Account</strong>
                    <small>Add an admin login without creating a student profile.</small>
                </span>
                <span class="admin-create-icon" aria-hidden="true">+</span>
            </summary>
            <form method="post" action="<?= base_url('admin/accounts/create'); ?>" class="admin-create-form">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                       value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label" for="new-admin-id">Admin ID</label>
                        <input id="new-admin-id" type="text" name="admin_id" class="form-control"
                               minlength="3" maxlength="50" pattern="[A-Za-z0-9_\-]+"
                               value="<?= set_value('admin_id'); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="new-admin-email">Email</label>
                        <input id="new-admin-email" type="email" name="email" class="form-control"
                               maxlength="150" value="<?= set_value('email'); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="new-admin-first-name">First Name</label>
                        <input id="new-admin-first-name" type="text" name="first_name" class="form-control"
                               minlength="2" maxlength="100" value="<?= set_value('first_name'); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="new-admin-last-name">Last Name</label>
                        <input id="new-admin-last-name" type="text" name="last_name" class="form-control"
                               minlength="2" maxlength="100" value="<?= set_value('last_name'); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="new-admin-password">Password</label>
                        <input id="new-admin-password" type="password" name="password" class="form-control"
                               minlength="8" maxlength="72" autocomplete="new-password" required>
                        <small class="form-text">Use at least 8 characters.</small>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="new-admin-confirm-password">Confirm Password</label>
                        <input id="new-admin-confirm-password" type="password" name="confirm_password"
                               class="form-control" minlength="8" maxlength="72" autocomplete="new-password" required>
                    </div>
                </div>
                <button type="submit" name="create_admin" value="1" class="btn btn-primary mt-3">
                    Create Admin Account
                </button>
            </form>
        </details>
        <?php endif; ?>

        <?php if ($admin_section === 'dashboard'): ?>
        <section class="admin-status-grid" aria-label="Request totals by status">
            <?php foreach ($counts as $status => $total): ?>
                <article class="admin-status-card admin-status-<?= strtolower($status); ?>">
                    <span><?= htmlspecialchars($status, ENT_QUOTES, 'UTF-8'); ?></span>
                    <strong><?= (int) $total; ?></strong>
                    <small>clearance requests</small>
                </article>
            <?php endforeach; ?>
        </section>

        <section class="admin-clearance-chart" aria-labelledby="clearance-chart-heading">
            <div class="admin-panel-heading">
                <div>
                    <h2 id="clearance-chart-heading">Clearance Process Overview</h2>
                    <p>Live totals from the current clearance request statuses.</p>
                </div>
            </div>
            <div class="admin-clearance-chart-canvas">
                <canvas id="clearance-status-chart"
                        role="img"
                        aria-label="Bar chart of pending, processing, cleared, and rejected clearance requests">
                    Clearance request totals by status are
                    Pending <?= (int) $counts['Pending']; ?>,
                    Processing <?= (int) $counts['Processing']; ?>,
                    Cleared <?= (int) $counts['Cleared']; ?>, and
                    Rejected <?= (int) $counts['Rejected']; ?>.
                </canvas>
            </div>
        </section>
        <?php endif; ?>

        <?php if ($admin_section === 'students'): ?>
        <section class="admin-requests-panel admin-students-panel" id="student-accounts">
            <div class="admin-panel-heading">
                <div>
                    <h2>Student Accounts</h2>
                    <p>Recently added accounts, including students created by spreadsheet imports.</p>
                </div>
                <span class="admin-request-total"><?= (int) $student_account_count; ?> total</span>
            </div>

            <div class="table-responsive">
                <table class="table align-middle admin-requests-table">
                    <thead>
                    <tr>
                        <th scope="col">Student ID</th>
                        <th scope="col">Student</th>
                        <th scope="col">Email</th>
                        <th scope="col">Course</th>
                        <th scope="col">Year Level</th>
                        <th scope="col">Contact</th>
                        <th scope="col">Added</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($student_accounts as $student_account): ?>
                        <tr>
                            <td><?= htmlspecialchars($student_account->student_id, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?= htmlspecialchars($student_account->first_name . ' ' . $student_account->last_name, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?= htmlspecialchars($student_account->email, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?= htmlspecialchars($student_account->course, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?= htmlspecialchars($student_account->year_level, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?= htmlspecialchars($student_account->contact_number, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?= htmlspecialchars($student_account->created_at, ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($student_accounts)): ?>
                        <tr>
                            <td colspan="7" class="admin-empty-state">No student accounts have been created yet.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($student_account_count > count($student_accounts)): ?>
                <p class="admin-roster-note">
                    Showing the <?= count($student_accounts); ?> most recently added accounts.
                </p>
            <?php endif; ?>
        </section>
        <?php endif; ?>

        <?php if ($admin_section === 'requests'): ?>
        <section class="admin-requests-panel" id="request-list">
            <div class="admin-panel-heading">
                <div>
                    <h2>Clearance Requests</h2>
                    <p>Update a request status and add remarks for the student.</p>
                </div>
                <span class="admin-request-total"><?= count($requests); ?> total</span>
            </div>

            <div class="table-responsive">
                <table class="table align-middle admin-requests-table">
                    <thead>
                    <tr>
                        <th scope="col">Student</th>
                        <th scope="col">School Year</th>
                        <th scope="col">Semester</th>
                        <th scope="col">Status</th>
                        <th scope="col">Update Request</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($requests as $request): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($request->first_name . ' ' . $request->last_name, ENT_QUOTES, 'UTF-8'); ?></strong>
                                <small class="d-block text-muted">ID: <?= htmlspecialchars($request->student_id, ENT_QUOTES, 'UTF-8'); ?></small>
                            </td>
                            <td><?= htmlspecialchars($request->school_year, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?= htmlspecialchars($request->semester, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td>
                                <span class="admin-status-pill admin-status-pill-<?= strtolower($request->status); ?>">
                                    <?= htmlspecialchars($request->status, ENT_QUOTES, 'UTF-8'); ?>
                                </span>
                                <small class="d-block text-muted mt-1">
                                    <?= htmlspecialchars($request->evaluation['label'], ENT_QUOTES, 'UTF-8'); ?>:
                                    <?= htmlspecialchars($request->evaluation['message'], ENT_QUOTES, 'UTF-8'); ?>
                                </small>
                            </td>
                            <td>
                                <form method="post" action="<?= base_url('admin/request/update/' . (int) $request->id); ?>" class="admin-update-form">
                                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                                           value="<?= $this->security->get_csrf_hash(); ?>">
                                    <label class="visually-hidden" for="request-status-<?= (int) $request->id; ?>">Status</label>
                                    <select id="request-status-<?= (int) $request->id; ?>" name="status" class="form-select form-select-sm" required>
                                        <?php foreach (array('Pending', 'Processing', 'Cleared', 'Rejected') as $status): ?>
                                            <option value="<?= $status; ?>" <?= $request->status === $status ? 'selected' : ''; ?>><?= $status; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label class="visually-hidden" for="request-remarks-<?= (int) $request->id; ?>">Remarks</label>
                                    <input id="request-remarks-<?= (int) $request->id; ?>" type="text" name="remarks"
                                           class="form-control form-control-sm" maxlength="1000" placeholder="Remarks"
                                           value="<?= htmlspecialchars((string) $request->remarks, ENT_QUOTES, 'UTF-8'); ?>">
                                    <button type="submit" name="update_request" value="1" class="btn btn-primary btn-sm">Save</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($requests)): ?>
                        <tr>
                            <td colspan="5" class="admin-empty-state">No clearance requests found.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
        <?php endif; ?>
    </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<script src="<?= base_url('assets/js/form-validation.js'); ?>"></script>
<script>
    alertify.set('notifier', 'position', 'top-right');
    alertify.set('notifier', 'delay', 4);
    <?php if ($this->session->flashdata('success')): ?>
    alertify.success(<?= json_encode(strip_tags($this->session->flashdata('success'))); ?>);
    <?php endif; ?>
    <?php if ($this->session->flashdata('error')): ?>
    alertify.error(<?= json_encode(strip_tags($this->session->flashdata('error'))); ?>);
    <?php endif; ?>
</script>
<?php if ($admin_section === 'dashboard'): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.5.0/dist/chart.umd.min.js"></script>
<?php endif; ?>
<script>
    (function () {
        var sendToAll = document.getElementById('email-all-students');
        var recipientSelect = document.getElementById('student-recipient-select');

        if (sendToAll && recipientSelect) {
            var updateRecipientControls = function () {
                recipientSelect.disabled = sendToAll.checked || recipientSelect.options.length === 0;
                recipientSelect.required = !sendToAll.checked && !recipientSelect.disabled;
            };
            sendToAll.addEventListener('change', function () {
                updateRecipientControls();
            });
            updateRecipientControls();
        }
    }());
</script>
<?php if ($admin_section === 'dashboard'): ?>
<script>
    (function () {
        var chartData = <?= $clearance_chart_json; ?>;
        var canvas = document.getElementById('clearance-status-chart');

        if (!canvas || typeof Chart === 'undefined') {
            return;
        }

        new Chart(canvas, {
            type: 'bar',
            data: {
                labels: chartData.labels,
                datasets: [{
                    label: 'Clearance requests',
                    data: chartData.counts,
                    backgroundColor: ['#c59d42', '#3b9eaa', '#36be8b', '#bd6265'],
                    borderRadius: 8,
                    maxBarThickness: 64
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(5, 18, 20, .96)',
                        titleColor: '#eafff9',
                        bodyColor: '#c6e9df',
                        borderColor: 'rgba(92, 226, 192, .35)',
                        borderWidth: 1,
                        callbacks: {
                            label: function (context) {
                                return ' ' + context.parsed.y + ' clearance requests';
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: '#a9c7c0'
                        },
                        grid: {
                            display: false,
                            color: 'rgba(139, 183, 170, .12)'
                        },
                        border: {
                            color: 'rgba(139, 183, 170, .24)'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            color: '#a9c7c0'
                        },
                        grid: {
                            color: 'rgba(139, 183, 170, .12)'
                        },
                        border: {
                            color: 'rgba(139, 183, 170, .24)'
                        }
                    }
                }
            }
        });
    }());
</script>
<?php endif; ?>
<script src="<?= base_url('assets/js/script.js'); ?>"></script>
</body>
</html>
