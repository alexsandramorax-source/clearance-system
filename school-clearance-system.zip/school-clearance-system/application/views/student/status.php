<?php
$page_title = 'Clearance Status';
$active_page = 'status';
$content_class = 'app-content--rounded';
$this->load->view('student/_header');
?>
<div class="container py-1">


    <div class="d-flex justify-content-between
                align-items-center mb-4">

        <div>

            <h1 class="app-page-heading">

                Clearance Status

            </h1>

            <p class="text-muted mb-0">

                Track your clearance approval.

            </p>

        </div>


        <a
            href="<?= base_url(
                'student/request'
            ); ?>"
            class="btn btn-primary">

            New Request

        </a>

    </div>


    <!-- ==========================================
         LATEST REQUEST
    =========================================== -->

    <?php if ($latest_request): ?>

        <div class="card shadow-sm border-0 mb-4">

            <div class="card-body">

                <div class="row">

                    <div class="col-md-4">

                        <small class="text-muted">
                            School Year
                        </small>

                        <h5>

                            <?= htmlspecialchars(
                                $latest_request
                                    ->school_year
                            ); ?>

                        </h5>

                    </div>


                    <div class="col-md-4">

                        <small class="text-muted">
                            Semester
                        </small>

                        <h5>

                            <?= htmlspecialchars(
                                $latest_request
                                    ->semester
                            ); ?>

                        </h5>

                    </div>


                    <div class="col-md-4">

                        <small class="text-muted">
                            Overall Status
                        </small>

                        <h5>

                        <?php

                        $overall =
                            $latest_request
                                ->status;

                        if (
                            $overall
                            ==
                            'Cleared'
                        ):

                        ?>

                            <span
                                class="badge bg-success">

                                Cleared

                            </span>

                        <?php elseif (
                            $overall
                            ==
                            'Rejected'
                        ): ?>

                            <span
                                class="badge bg-danger">

                                Rejected

                            </span>

                        <?php elseif (
                            $overall
                            ==
                            'Processing'
                        ): ?>

                            <span
                                class="badge bg-warning text-dark">

                                Processing

                            </span>

                        <?php else: ?>

                            <span
                                class="badge bg-secondary">

                                Pending

                            </span>

                        <?php endif; ?>

                        </h5>

                        <div class="alert alert-<?= htmlspecialchars($latest_evaluation['tone'], ENT_QUOTES, 'UTF-8'); ?> py-2 mb-0" role="status">
                            <strong><?= htmlspecialchars($latest_evaluation['label'], ENT_QUOTES, 'UTF-8'); ?>:</strong>
                            <?= htmlspecialchars($latest_evaluation['message'], ENT_QUOTES, 'UTF-8'); ?>
                        </div>

                    </div>

                </div>

            </div>

        </div>

        <!-- ======================================
             DEPARTMENT STATUS
        ======================================= -->

        <div class="card shadow-sm border-0">

            <div class="card-body">

                <h5 class="fw-bold mb-3">

                    Department Status

                </h5>


                <div class="table-responsive">

                    <table class="table table-hover">

                        <thead class="table-primary">

                            <tr>

                                <th>#</th>

                                <th>Department</th>

                                <th>Status</th>

                                <th>Remarks</th>

                            </tr>

                        </thead>


                        <tbody>

                        <?php if (
                            !empty($statuses)
                        ): ?>

                            <?php $count = 1; ?>


                            <?php foreach (
                                $statuses
                                as $status
                            ): ?>

                                <tr>

                                    <td>

                                        <?= $count++; ?>

                                    </td>


                                    <td class="fw-semibold">

                                        <?= htmlspecialchars(
                                            $status
                                                ->department_name
                                        ); ?>

                                    </td>


                                    <td>

                                    <?php if (
                                        $status
                                            ->status
                                        ==
                                        'Approved'
                                    ): ?>

                                        <span
                                            class="badge bg-success">

                                            Approved

                                        </span>

                                    <?php elseif (
                                        $status
                                            ->status
                                        ==
                                        'Rejected'
                                    ): ?>

                                        <span
                                            class="badge bg-danger">

                                            Rejected

                                        </span>

                                    <?php else: ?>

                                        <span
                                            class="badge bg-secondary">

                                            Pending

                                        </span>

                                    <?php endif; ?>

                                    </td>


                                    <td>

                                        <?= !empty(
                                            $status
                                                ->remarks
                                        )

                                            ?

                                            htmlspecialchars(
                                                $status
                                                    ->remarks
                                            )

                                            :

                                            '<span class="text-muted">
                                                No remarks
                                             </span>';

                                        ?>

                                    </td>

                                </tr>

                            <?php endforeach; ?>


                        <?php else: ?>

                            <tr>

                                <td
                                    colspan="4"
                                    class="text-center">

                                    No department status
                                    available.

                                </td>

                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>


            </div>

        </div>





    <?php else: ?>


        <div class="status-empty">

                <h2>
                    No Clearance Request
                </h2>

                <p class="text-muted">

                    You have not submitted a
                    clearance request yet.

                </p>


                <a
                    href="<?= base_url(
                        'student/request'
                    ); ?>"
                    class="app-action">

                    Request Clearance

                </a>

        </div>


    <?php endif; ?>


    <!-- ==========================================
         REQUEST HISTORY
    =========================================== -->

    <div class="history-panel mt-4">

        <div class="card-body">

            <h5 class="fw-bold">

                Request History

            </h5>


            <div class="table-responsive mt-3">

                <table class="table table-hover">

                    <thead>

                        <tr>

                            <th>School Year</th>

                            <th>Semester</th>

                            <th>Status</th>

                            <th>Date</th>

                            <th>Action</th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php if (
                        !empty($requests)
                    ): ?>


                        <?php foreach (
                            $requests
                            as $request
                        ): ?>

                            <tr>

                                <td>

                                    <?= htmlspecialchars(
                                        $request
                                            ->school_year
                                    ); ?>

                                </td>


                                <td>

                                    <?= htmlspecialchars(
                                        $request
                                            ->semester
                                    ); ?>

                                </td>


                                <td>

                                <?php if (
                                    $request
                                        ->status
                                    ==
                                    'Cleared'
                                ): ?>

                                    <span
                                        class="badge bg-success">

                                        Cleared

                                    </span>

                                <?php elseif (
                                    $request
                                        ->status
                                    ==
                                    'Rejected'
                                ): ?>

                                    <span
                                        class="badge bg-danger">

                                        Rejected

                                    </span>

                                <?php elseif (
                                    $request
                                        ->status
                                    ==
                                    'Processing'
                                ): ?>

                                    <span
                                        class="badge bg-warning text-dark">

                                        Processing

                                    </span>

                                <?php else: ?>

                                    <span
                                        class="badge bg-secondary">

                                        Pending

                                    </span>

                                <?php endif; ?>

                                </td>


                                <td>

                                    <?= date(
                                        'M d, Y',
                                        strtotime(
                                            $request
                                                ->created_at
                                        )
                                    ); ?>

                                </td>


                                <td>

                               <?php if ($request->status == 'Pending'): ?>

                                
                                    <a href="<?= base_url(
                                        'student/request/edit/'
                                        . $request->id
                                    ); ?>"
                                    class="btn btn-sm btn-primary">

                                    Edit

                                </a>


                                <form method="post"
                                      action="<?= base_url('student/request/delete/' . (int) $request->id); ?>"
                                      class="d-inline"
                                      onsubmit="return confirm('Delete this pending clearance request?');">
                                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                                           value="<?= $this->security->get_csrf_hash(); ?>">
                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                </form>

                            <?php else: ?>

                                <span class="text-muted">

                                    No action

                                </span>

                            <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>


                    <?php else: ?>

                        <tr>

                            <td
                                colspan="5"
                                class="text-center text-muted">

                                No request history.

                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<script>
alertify.set('notifier', 'position', 'top-right');
alertify.set('notifier', 'delay', 3);

/*
|--------------------------------------------------------------------------
| SUCCESS MESSAGE
|--------------------------------------------------------------------------
*/

<?php if ($this->session->flashdata('success')): ?>

alertify.success(
    <?= json_encode(
        $this->session->flashdata('success')
    ); ?>
);

<?php endif; ?>


/*
|--------------------------------------------------------------------------
| ERROR MESSAGE
|--------------------------------------------------------------------------
*/

<?php if ($this->session->flashdata('error')): ?>

alertify.error(
    <?= json_encode(
        strip_tags(
            $this->session->flashdata('error')
        )
    ); ?>
);

<?php endif; ?>

</script>

<?php $this->load->view('student/_footer'); ?>