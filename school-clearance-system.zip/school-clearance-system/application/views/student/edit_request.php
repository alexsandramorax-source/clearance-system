<?php
$page_title = 'Edit Clearance Request';
$active_page = 'status';
$this->load->view('student/_header');
?>
<div class="container py-4">

    <div class="row justify-content-center">

        <div class="col-md-7">

            <div class="card shadow border-0">

                <div class="card-body p-4">


                    <h3 class="fw-bold">

                        Edit Clearance Request

                    </h3>


                    <p class="text-muted">

                        Update your pending clearance
                        request.

                    </p>


                    <form
                        method="POST"
                        action="<?= base_url(
                            'student/request/edit/'
                            . $request->id
                        ); ?>">
                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                               value="<?= $this->security->get_csrf_hash(); ?>">


                        <!-- SCHOOL YEAR -->

                        <div class="mb-3">

                            <label class="form-label">

                                School Year

                            </label>


                            <input
                                type="text"
                                name="school_year"
                                class="form-control"
                                minlength="9"
                                maxlength="9"
                                pattern="[0-9]{4}-[0-9]{4}"
                                placeholder="Example: 2026-2027"
                                value="<?= htmlspecialchars(
                                    $request
                                        ->school_year
                                ); ?>"
                                required>


                        </div>


                        <!-- SEMESTER -->

                        <div class="mb-4">

                            <label class="form-label">

                                Semester

                            </label>


                            <select
                                name="semester"
                                class="form-select"
                                required>


                                <option value="">

                                    Select Semester

                                </option>


                                <option
                                    value="1st Semester"
                                    <?= $request->semester
                                        ==
                                        '1st Semester'
                                        ? 'selected'
                                        : ''; ?>>

                                    1st Semester

                                </option>


                                <option
                                    value="2nd Semester"
                                    <?= $request->semester
                                        ==
                                        '2nd Semester'
                                        ? 'selected'
                                        : ''; ?>>

                                    2nd Semester

                                </option>


                                <option
                                    value="Summer"
                                    <?= $request->semester
                                        ==
                                        'Summer'
                                        ? 'selected'
                                        : ''; ?>>

                                    Summer

                                </option>


                            </select>

                        </div>


                        <!-- INFO -->

                        <div class="alert alert-warning">

                            <strong>Note:</strong>

                            You can only edit a clearance
                            request while its status is
                            <strong>Pending</strong>.

                        </div>


                        <!-- BUTTONS -->

                        <button
                            type="submit"
                            name="update_request"
                            value="1"
                            class="btn btn-primary">

                            Update Request

                        </button>


                        <a
                            href="<?= base_url(
                                'student/status'
                            ); ?>"
                            class="btn btn-secondary">

                            Cancel

                        </a>


                    </form>


                </div>

            </div>

        </div>

    </div>

</div>


<!-- ==========================================
     ALERTIFY
=========================================== -->

<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>


<script>
alertify.set('notifier', 'position', 'top-right');
alertify.set('notifier', 'delay', 3);


<?php if (
    $this->session->flashdata('error')
): ?>

alertify.error(
    <?= json_encode(
        strip_tags(
            $this->session
                ->flashdata('error')
        )
    ); ?>
);

<?php endif; ?>


<?php if (
    $this->session->flashdata('success')
): ?>

alertify.success(
    <?= json_encode(
        $this->session
            ->flashdata('success')
    ); ?>
);

<?php endif; ?>


</script>


<?php $this->load->view('student/_footer'); ?>