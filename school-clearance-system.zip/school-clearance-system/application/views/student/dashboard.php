<?php
$page_title = 'Student Dashboard';
$active_page = 'requirements';
$this->load->view('student/_header');
?>
<div class="container py-1">
    <div class="d-flex justify-content-between align-items-center mb-2">
        <h1 class="app-page-heading">Clearance Requirements</h1>
        <a href="<?= base_url('student/status'); ?>" class="btn btn-secondary app-back">Back</a>
    </div>

    <div class="requirement-grid">
        <?php if (!empty($requirements)): ?>
            <?php $shown_departments = array(); ?>
            <?php foreach ($requirements as $requirement): ?>
                <?php
                $department_key = strtolower($requirement->department_name);
                if (isset($shown_departments[$department_key])) {
                    continue;
                }
                $shown_departments[$department_key] = TRUE;
                ?>
                <article class="requirement-card">
                    <header>
                        <h2><?= htmlspecialchars($requirement->department_name); ?></h2>
                        <p><?= htmlspecialchars($requirement->description); ?></p>
                    </header>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-muted">No clearance requirements available.</p>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<script>
alertify.set('notifier', 'position', 'top-right');
alertify.set('notifier', 'delay', 3);
<?php if ($this->session->flashdata('success')): ?>
alertify.success(<?= json_encode($this->session->flashdata('success')); ?>);
<?php endif; ?>
<?php if ($this->session->flashdata('error')): ?>
alertify.error(<?= json_encode(strip_tags($this->session->flashdata('error'))); ?>);
<?php endif; ?>
</script>

<?php $this->load->view('student/_footer'); ?>
