<?php
$page_title = 'My Profile';
$active_page = 'profile';
$this->load->view('student/_header');
$full_name = trim($user->first_name . ' ' . $user->last_name);
?>
<div class="container py-2">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h1 class="app-page-heading">My Profile</h1>
            <p class="app-subheading">Your student account and contact information.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= base_url('student/profile/edit'); ?>" class="app-action">Edit Information</a>
            <a href="<?= base_url('student/dashboard'); ?>" class="app-back">Dashboard</a>
        </div>
    </div>

    <section class="card profile-account mb-3" aria-labelledby="account-information-heading">
        <div class="card-body">
            <div class="profile-avatar">
                <?php if (!empty($student->profile_photo)): ?>
                    <img src="<?= base_url(htmlspecialchars($student->profile_photo, ENT_QUOTES, 'UTF-8')); ?>"
                         alt="<?= htmlspecialchars($full_name, ENT_QUOTES, 'UTF-8'); ?> profile photo">
                <?php else: ?>
                    <span aria-hidden="true"><?= htmlspecialchars(strtoupper(substr($user->first_name, 0, 1) . substr($user->last_name, 0, 1)), ENT_QUOTES, 'UTF-8'); ?></span>
                <?php endif; ?>
            </div>
            <h2 id="account-information-heading" class="fw-bold"><?= htmlspecialchars($full_name, ENT_QUOTES, 'UTF-8'); ?></h2>
            <p class="profile-course-line"><?= htmlspecialchars($student->course . ' · ' . $student->year_level, ENT_QUOTES, 'UTF-8'); ?></p>
            <div class="row mt-3">
                <div class="col-md-6">
                    <small class="text-muted">Student ID</small>
                    <p class="fw-semibold"><?= htmlspecialchars($user->student_id, ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
                <div class="col-md-6">
                    <small class="text-muted">Email</small>
                    <p class="fw-semibold"><?= htmlspecialchars($user->email, ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
                <div class="col-md-6">
                    <small class="text-muted">First Name</small>
                    <p class="fw-semibold"><?= htmlspecialchars($user->first_name, ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
                <div class="col-md-6">
                    <small class="text-muted">Last Name</small>
                    <p class="fw-semibold"><?= htmlspecialchars($user->last_name, ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
            </div>
        </div>
    </section>

    <section class="card profile-student-info mb-3" aria-labelledby="student-information-heading">
        <div class="card-body">
            <h2 id="student-information-heading" class="fw-bold">Student Information</h2>
            <div class="row mt-3">
                <div class="col-md-6">
                    <small class="text-muted">Course</small>
                    <p class="fw-semibold"><?= htmlspecialchars($student->course, ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
                <div class="col-md-6">
                    <small class="text-muted">Year Level</small>
                    <p class="fw-semibold"><?= htmlspecialchars($student->year_level, ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
                <div class="col-md-6">
                    <small class="text-muted">Contact Number</small>
                    <p class="fw-semibold"><?= htmlspecialchars($student->contact_number, ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
                <div class="col-md-6">
                    <small class="text-muted">Address</small>
                    <p class="fw-semibold"><?= htmlspecialchars($student->address, ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
            </div>
        </div>
    </section>
</div>

<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<script>
alertify.set('notifier', 'position', 'top-right');
alertify.set('notifier', 'delay', 3);
<?php if ($this->session->flashdata('success')): ?>
alertify.success(<?= json_encode($this->session->flashdata('success')); ?>);
<?php endif; ?>
<?php if ($this->session->flashdata('error')): ?>
alertify.error(<?= json_encode(strip_tags($this->session->flashdata('error'))); ?>);
<?php endif; ?>
</script>

<?php $this->load->view('student/_footer'); ?>
