<?php
$page_title = 'Request Clearance';
$active_page = 'request';
$this->load->view('student/_header');
?>
<div class="container py-4">

    <h1 class="app-page-heading">Request Clearance</h1>
    <p class="app-subheading">You have not submitted a clearance request yet.</p>
    <p class="text-muted">Complete both required fields to submit your request.</p>

    <div class="request-form-card">


                    <form
                        method="POST"
                        action="<?= base_url(
                            'student/request'
                        ); ?>">
                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                               value="<?= $this->security->get_csrf_hash(); ?>">


                        <div class="mb-3">

                            <label class="form-label">

                                School Year

                            </label>

                            <input
                                type="text"
                                name="school_year"
                                class="form-control"
                                minlength="9"
                                maxlength="9"
                                pattern="[0-9]{4}-[0-9]{4}"
                                placeholder="Example: 2026-2027"
                                value="<?= set_value(
                                    'school_year'
                                ); ?>"
                                required>

                        </div>


                        <div class="mb-4">

                            <label class="form-label">

                                Semester

                            </label>

                            <select
                                name="semester"
                                class="form-select"
                                required>

                                <option value="">
                                    Select Semester
                                </option>

                                <option value="1st Semester" <?= set_select('semester', '1st Semester'); ?>>
                                    1st Semester
                                </option>

                                <option value="2nd Semester" <?= set_select('semester', '2nd Semester'); ?>>
                                    2nd Semester
                                </option>

                                <option value="Summer" <?= set_select('semester', 'Summer'); ?>>
                                    Summer
                                </option>

                            </select>

                        </div>


                        <div class="alert alert-info">

                            After submitting your request,
                            all departments will receive a
                            <strong>Pending</strong> clearance
                            status for your account.

                        </div>


                        <button
                            type="submit"
                            name="submit_request"
                            value="1"
                            class="btn btn-primary w-100">

                            Submit Clearance Request

                        </button>


                    </form>


                    <div class="text-center mt-2">

                        <a
                            href="<?= base_url(
                                'student/dashboard'
                            ); ?>">

                            Back to Dashboard

                        </a>

            </div>

        </div>

    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

<script>
alertify.set('notifier', 'position', 'top-right');
alertify.set('notifier', 'delay', 3);

<?php if (
    $this->session->flashdata('error')
): ?>

alertify.error(
    <?= json_encode(
        strip_tags(
            $this->session
                ->flashdata('error')
        )
    ); ?>
);

<?php endif; ?>

</script>

<?php $this->load->view('student/_footer'); ?>