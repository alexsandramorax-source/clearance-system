<?php
$page_title = isset($page_title) ? $page_title : 'School Clearance';
$active_page = isset($active_page) ? $active_page : '';
$content_class = isset($content_class) ? $content_class : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title); ?> | School Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>?v=<?= filemtime(FCPATH . 'assets/css/style.css'); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css">
</head>
<body class="student-page">
<header class="app-topbar">
    <button class="app-menu-toggle" type="button" aria-label="Toggle navigation" aria-expanded="true">
        <span></span><span></span><span></span>
    </button>
    <a class="app-brand" href="<?= base_url('student/dashboard'); ?>">School Clearance</a>
    <?php
    $header_first_name = (string) $this->session->userdata('first_name');
    $header_last_name = (string) $this->session->userdata('last_name');
    $header_email = (string) $this->session->userdata('email');
    $header_student_id = (string) $this->session->userdata('student_id');
    $header_profile_photo = (string) $this->session->userdata('profile_photo');
    $header_display_name = trim($header_first_name . ' ' . $header_last_name);
    $header_initials = strtoupper(substr($header_first_name, 0, 1) . substr($header_last_name, 0, 1));
    ?>
    <details class="profile-menu" id="student-profile-menu">
        <summary class="profile-menu-toggle">
            <span class="profile-menu-avatar" aria-hidden="true">
                <?php if ($header_profile_photo !== ''): ?>
                    <img src="<?= base_url(htmlspecialchars($header_profile_photo, ENT_QUOTES, 'UTF-8')); ?>"
                         alt="" class="profile-menu-avatar-image">
                <?php else: ?>
                    <?= htmlspecialchars($header_initials, ENT_QUOTES, 'UTF-8'); ?>
                <?php endif; ?>
            </span>
            <span class="profile-menu-name"><?= htmlspecialchars($header_first_name ?: 'Profile', ENT_QUOTES, 'UTF-8'); ?></span>
            <span class="profile-menu-chevron" aria-hidden="true">⌄</span>
        </summary>
        <div class="profile-menu-dropdown">
            <div class="profile-menu-summary">
                <strong><?= htmlspecialchars($header_display_name ?: 'Student', ENT_QUOTES, 'UTF-8'); ?></strong>
                <span><?= htmlspecialchars($header_email, ENT_QUOTES, 'UTF-8'); ?></span>
                <small>Student ID: <?= htmlspecialchars($header_student_id, ENT_QUOTES, 'UTF-8'); ?></small>
            </div>
            <a class="profile-menu-link" href="<?= base_url('student/profile'); ?>">View profile</a>
            <form class="profile-menu-logout" method="post" action="<?= base_url('logout'); ?>"
                  onsubmit="return confirm('Are you sure you want to log out?');">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                       value="<?= $this->security->get_csrf_hash(); ?>">
                <button type="submit">Log out</button>
            </form>
        </div>
    </details>
</header>
<nav class="app-sidebar" aria-label="Student navigation">
    <a class="<?= $active_page === 'status' ? 'is-active' : ''; ?>" href="<?= base_url('student/status'); ?>" aria-label="Clearance status" title="Clearance status"><span aria-hidden="true">▤</span><span class="nav-label">Status</span></a>
    <a class="<?= $active_page === 'requirements' ? 'is-active' : ''; ?>" href="<?= base_url('student/requirements'); ?>" aria-label="Clearance requirements" title="Clearance requirements"><span aria-hidden="true">▥</span><span class="nav-label">Requirements</span></a>
    <a class="<?= $active_page === 'request' ? 'is-active' : ''; ?>" href="<?= base_url('student/request'); ?>" aria-label="Request clearance" title="Request clearance"><span aria-hidden="true">✎</span><span class="nav-label">Request</span></a>
    <a class="<?= $active_page === 'profile' ? 'is-active' : ''; ?>" href="<?= base_url('student/profile'); ?>" aria-label="My profile" title="My profile"><span aria-hidden="true">♙</span><span class="nav-label">Profile</span></a>
</nav>
<main class="app-main">
    <div class="app-content <?= htmlspecialchars($content_class); ?>">
