<?php
$page_title = 'Update Profile';
$active_page = 'profile';
$profile_error = $this->session->flashdata('error');
$profile_success = $this->session->flashdata('success');
$this->load->view('student/_header');
?>
<div class="container py-2">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h1 class="app-page-heading">Update Profile</h1>
            <p class="app-subheading">Edit your account and student information.</p>
        </div>
        <a href="<?= base_url('student/profile'); ?>" class="app-back">Cancel</a>
    </div>

    <section class="card profile-edit-card" aria-labelledby="profile-edit-heading">
        <div class="card-body">
            <h2 id="profile-edit-heading" class="fw-bold">Student Credentials</h2>
            <p class="text-muted">Your changes will be saved to your profile.</p>
            <?php if ($profile_error): ?>
                <div class="alert alert-danger" role="alert"><?= htmlspecialchars(strip_tags($profile_error), ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
            <?php if ($profile_success): ?>
                <div class="alert alert-success" role="status"><?= htmlspecialchars($profile_success, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
            <div class="profile-edit-photo">
                <div class="profile-avatar profile-edit-avatar">
                    <?php if (!empty($student->profile_photo)): ?>
                        <img src="<?= base_url(htmlspecialchars($student->profile_photo, ENT_QUOTES, 'UTF-8')); ?>"
                             alt="<?= htmlspecialchars(trim($user->first_name . ' ' . $user->last_name), ENT_QUOTES, 'UTF-8'); ?> profile photo">
                    <?php else: ?>
                        <span aria-hidden="true"><?= htmlspecialchars(strtoupper(substr($user->first_name, 0, 1) . substr($user->last_name, 0, 1)), ENT_QUOTES, 'UTF-8'); ?></span>
                    <?php endif; ?>
                </div>
                <form class="profile-edit-photo-form" method="post"
                      action="<?= base_url('student/profile/photo'); ?>" enctype="multipart/form-data">
                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                           value="<?= $this->security->get_csrf_hash(); ?>">
                    <label class="form-label" for="profile-photo">Profile photo</label>
                    <input id="profile-photo" type="file" name="profile_photo" class="form-control"
                           accept="image/jpeg,image/png,image/webp" required>
                    <small class="text-muted">JPG, PNG, or WebP · max 2 MB</small>
                    <button type="submit" class="btn btn-outline-primary mt-2">Update Photo</button>
                </form>
            </div>
            <form method="post" action="<?= base_url('student/profile/update'); ?>">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                       value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="row mt-3">
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="profile-student-id">Student ID</label>
                        <input id="profile-student-id" type="text" name="student_id" class="form-control"
                               inputmode="numeric" minlength="3" maxlength="50" pattern="[0-9]{3,50}" required
                               value="<?= htmlspecialchars($user->student_id, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="profile-email">Email</label>
                        <input id="profile-email" type="email" name="email" class="form-control"
                               maxlength="150" pattern="[^@]+@[^@]+" required
                               value="<?= htmlspecialchars($user->email, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="profile-first-name">First Name</label>
                        <input id="profile-first-name" type="text" name="first_name" class="form-control"
                               minlength="2" maxlength="100" required
                               value="<?= htmlspecialchars($user->first_name, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="profile-last-name">Last Name</label>
                        <input id="profile-last-name" type="text" name="last_name" class="form-control"
                               minlength="2" maxlength="100" required
                               value="<?= htmlspecialchars($user->last_name, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="profile-course">Course</label>
                        <input id="profile-course" type="text" name="course" class="form-control"
                               maxlength="150" required
                               value="<?= htmlspecialchars($student->course, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="profile-year-level">Year Level</label>
                        <select id="profile-year-level" name="year_level" class="form-select" required>
                            <?php foreach (array('1st Year', '2nd Year', '3rd Year', '4th Year') as $year_level): ?>
                                <option value="<?= $year_level; ?>" <?= $student->year_level === $year_level ? 'selected' : ''; ?>>
                                    <?= $year_level; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="profile-contact-number">Contact Number</label>
                        <input id="profile-contact-number" type="text" name="contact_number" class="form-control"
                               minlength="7" maxlength="30" pattern="[0-9+\(\) \-]{7,30}" required
                               value="<?= htmlspecialchars($student->contact_number, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="profile-address">Address</label>
                        <input id="profile-address" type="text" name="address" class="form-control"
                               maxlength="255" required
                               value="<?= htmlspecialchars($student->address, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                </div>
                <div class="d-flex flex-wrap gap-2 mt-2">
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                    <a href="<?= base_url('student/profile'); ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </section>
</div>

<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<script>
alertify.set('notifier', 'position', 'top-right');
alertify.set('notifier', 'delay', 4);
<?php if ($profile_error): ?>
alertify.error(<?= json_encode(strip_tags($profile_error)); ?>);
<?php endif; ?>
<?php if ($profile_success): ?>
alertify.success(<?= json_encode($profile_success); ?>);
<?php endif; ?>
</script>

<?php $this->load->view('student/_footer'); ?>
