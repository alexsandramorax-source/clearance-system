<?php
$page_title = 'Clearance Requirements';
$active_page = 'requirements';
$this->load->view('student/_header');
?>
<div class="container py-4">

    <div class="d-flex justify-content-between
                align-items-center mb-4">

        <div>

            <h1 class="app-page-heading">
                Clearance Requirements
            </h1>

            <p class="text-muted mb-0">
                Requirements from each department
            </p>

        </div>


        <a
            href="<?= base_url('student/dashboard'); ?>"
            class="btn btn-secondary">

            Back

        </a>

    </div>


    <div class="requirement-grid">

        <?php if (!empty($requirements)): ?>
            <?php foreach ($requirements as $requirement): ?>
                <article class="requirement-card">
                    <header>
                        <h2><?= htmlspecialchars($requirement->department_name); ?></h2>
                        <p><?= htmlspecialchars($requirement->description); ?></p>
                    </header>
                    <div class="p-3">
                        <strong><?= htmlspecialchars($requirement->requirement_name); ?></strong>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-muted">No clearance requirements available.</p>
        <?php endif; ?>

    </div>

</div>

<?php $this->load->view('student/_footer'); ?>