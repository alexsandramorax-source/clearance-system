    </div>
</main>
<script src="<?= base_url('assets/js/script.js'); ?>"></script>
<script src="<?= base_url('assets/js/form-validation.js'); ?>"></script>
</body>
</html>
