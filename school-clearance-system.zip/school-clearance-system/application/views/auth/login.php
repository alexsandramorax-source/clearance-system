<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in | Capitol University Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css">
</head>
<body class="auth-page auth-page--login">
    <main class="auth-card auth-card--login">
        <div class="login-orb" aria-hidden="true">CU</div>
        <h1 class="auth-title">Welcome back</h1>
        <p class="auth-subtitle">Sign in to manage your school clearance.</p>

        <form method="post" action="<?= base_url('login'); ?>">
            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                   value="<?= $this->security->get_csrf_hash(); ?>">

            <div class="mb-3">
                <label class="form-label" for="login-email">Email address</label>
                <input id="login-email" type="email" name="email" class="form-control"
                       placeholder="Enter your email" autocomplete="email" maxlength="150"
                       value="<?= htmlspecialchars(set_value('email'), ENT_QUOTES, 'UTF-8'); ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label" for="login-password">Password</label>
                <input id="login-password" type="password" name="password" class="form-control"
                       placeholder="Enter your password" autocomplete="current-password" required>
            </div>

            <button type="submit" class="btn btn-primary w-100">Log in</button>
        </form>

        <div class="auth-links">
            <span>Don't have a student account?</span>
            <a href="<?= base_url('register'); ?>">Register</a>
        </div>

        <?php if (!empty($first_admin_setup_available)): ?>
            <section class="auth-first-admin">
                <strong>Setting up the system?</strong>
                <p>No administrator account exists yet.</p>
                <a href="<?= base_url('admin/setup'); ?>">Create the first admin account</a>
            </section>
        <?php endif; ?>

        <div class="auth-links">
            <a href="<?= base_url('home'); ?>">Back to homepage</a>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
    <script src="<?= base_url('assets/js/form-validation.js'); ?>"></script>
    <script>
    alertify.set('notifier', 'position', 'top-right');
    alertify.set('notifier', 'delay', 4);
    <?php if ($this->session->flashdata('success')): ?>
    alertify.success(<?= json_encode($this->session->flashdata('success')); ?>);
    <?php endif; ?>
    <?php if ($this->session->flashdata('error')): ?>
    alertify.error(<?= json_encode(strip_tags($this->session->flashdata('error'))); ?>);
    <?php endif; ?>
    </script>
</body>
</html>
