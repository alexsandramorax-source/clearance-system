<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Registration</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">

    <!-- Alertify CSS -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css">

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/bootstrap.min.css">

</head>


<body class="auth-page">

<div class="container py-5">

    <div class="row justify-content-center">

        <div class="col-lg-8">

            <div class="auth-card">

                <div class="card-body p-4">

                    <h1 class="auth-title">
                        Student Registration
                    </h1>

                    <p class="auth-subtitle">
                        Create your student account
                    </p>
                    <p class="text-muted text-center">All fields are required.</p>

                    <?php if ($this->session->flashdata('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?= htmlspecialchars(strip_tags($this->session->flashdata('error')), ENT_QUOTES, 'UTF-8'); ?>
                        </div>
                    <?php endif; ?>

                    <!-- REGISTRATION FORM -->
                    <form method="POST"
                          action="<?= base_url('register'); ?>"
                          data-inline-validation>
                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                               value="<?= $this->security->get_csrf_hash(); ?>">


                        <!-- STUDENT ID + EMAIL -->
                        <div class="row">

                            <div class="col-md-6 mb-3">

                                <label class="form-label">
                                    Student ID
                                </label>

                                <input
                                    type="text"
                                    name="student_id"
                                    class="form-control <?= form_error('student_id') ? 'is-invalid' : ''; ?>"
                                    inputmode="numeric"
                                    minlength="3"
                                    maxlength="50"
                                    pattern="[0-9]{3,50}"
                                    value="<?= set_value('student_id'); ?>"
                                    placeholder="Enter Student ID"
                                    required>
                                <?php if (form_error('student_id')): ?>
                                    <div class="invalid-feedback d-block inline-validation-feedback server-validation-feedback"><?= htmlspecialchars(strip_tags(form_error('student_id')), ENT_QUOTES, 'UTF-8'); ?></div>
                                <?php endif; ?>

                            </div>


                            <div class="col-md-6 mb-3">

                                <label class="form-label">
                                    Email
                                </label>

                                <input
                                    type="email"
                                    name="email"
                                    class="form-control <?= form_error('email') ? 'is-invalid' : ''; ?>"
                                    maxlength="150"
                                    pattern="[^@]+@[^@]+"
                                    value="<?= set_value('email'); ?>"
                                    placeholder="Enter Email"
                                    required>
                                <?php if (form_error('email')): ?>
                                    <div class="invalid-feedback d-block inline-validation-feedback server-validation-feedback"><?= htmlspecialchars(strip_tags(form_error('email')), ENT_QUOTES, 'UTF-8'); ?></div>
                                <?php endif; ?>

                            </div>

                        </div>


                        <!-- FIRST NAME + LAST NAME -->
                        <div class="row">

                            <div class="col-md-6 mb-3">

                                <label class="form-label">
                                    First Name
                                </label>

                                <input
                                    type="text"
                                    name="first_name"
                                    class="<?= form_error('first_name') ? 'form-control is-invalid' : 'form-control'; ?>"
                                    minlength="2"
                                    maxlength="100"
                                    value="<?= set_value('first_name'); ?>"
                                    placeholder="First Name"
                                    required>
                                <?php if (form_error('first_name')): ?>
                                    <div class="invalid-feedback d-block inline-validation-feedback server-validation-feedback"><?= htmlspecialchars(strip_tags(form_error('first_name')), ENT_QUOTES, 'UTF-8'); ?></div>
                                <?php endif; ?>

                            </div>


                            <div class="col-md-6 mb-3">

                                <label class="form-label">
                                    Last Name
                                </label>

                                <input
                                    type="text"
                                    name="last_name"
                                    minlength="2"
                                    maxlength="100"
                                    value="<?= set_value('last_name'); ?>"
                                    placeholder="Last Name"
                                    class="<?= form_error('last_name') ? 'form-control is-invalid' : 'form-control'; ?>"
                                    required>
                                <?php if (form_error('last_name')): ?>
                                    <div class="invalid-feedback d-block inline-validation-feedback server-validation-feedback"><?= htmlspecialchars(strip_tags(form_error('last_name')), ENT_QUOTES, 'UTF-8'); ?></div>
                                <?php endif; ?>

                            </div>

                        </div>


                        <!-- COURSE + YEAR LEVEL -->
                        <div class="row">

                            <div class="col-md-6 mb-3">

                                <label class="form-label">
                                    Course
                                </label>

                                <input
                                    type="text"
                                    name="course"
                                    class="<?= form_error('course') ? 'form-control is-invalid' : 'form-control'; ?>"
                                    maxlength="150"
                                    value="<?= set_value('course'); ?>"
                                    placeholder="Example: BSIT"
                                    required>
                                <?php if (form_error('course')): ?>
                                    <div class="invalid-feedback d-block inline-validation-feedback server-validation-feedback"><?= htmlspecialchars(strip_tags(form_error('course')), ENT_QUOTES, 'UTF-8'); ?></div>
                                <?php endif; ?>

                            </div>


                            <div class="col-md-6 mb-3">

                                <label class="form-label">
                                    Year Level
                                </label>

                                <select
                                    name="year_level"
                                    class="<?= form_error('year_level') ? 'form-select is-invalid' : 'form-select'; ?>"
                                    required>

                                    <option value="">
                                        Select Year Level
                                    </option>

                                    <option value="1st Year"
                                        <?= set_select('year_level', '1st Year'); ?>>
                                        1st Year
                                    </option>

                                    <option value="2nd Year"
                                        <?= set_select('year_level', '2nd Year'); ?>>
                                        2nd Year
                                    </option>

                                    <option value="3rd Year"
                                        <?= set_select('year_level', '3rd Year'); ?>>
                                        3rd Year
                                    </option>

                                    <option value="4th Year"
                                        <?= set_select('year_level', '4th Year'); ?>>
                                        4th Year
                                    </option>

                                </select>
                                <?php if (form_error('year_level')): ?>
                                    <div class="invalid-feedback d-block inline-validation-feedback server-validation-feedback"><?= htmlspecialchars(strip_tags(form_error('year_level')), ENT_QUOTES, 'UTF-8'); ?></div>
                                <?php endif; ?>

                            </div>

                        </div>


                        <!-- CONTACT -->
                        <div class="mb-3">

                            <label class="form-label">
                                Contact Number
                            </label>

                            <input
                                type="text"
                                name="contact_number"
                                class="<?= form_error('contact_number') ? 'form-control is-invalid' : 'form-control'; ?>"
                                minlength="7"
                                maxlength="30"
                                pattern="[0-9+\(\) \-]{7,30}"
                                value="<?= set_value('contact_number'); ?>"
                                placeholder="09XXXXXXXXX"
                                required>
                            <?php if (form_error('contact_number')): ?>
                                <div class="invalid-feedback d-block inline-validation-feedback server-validation-feedback"><?= htmlspecialchars(strip_tags(form_error('contact_number')), ENT_QUOTES, 'UTF-8'); ?></div>
                            <?php endif; ?>

                        </div>


                        <!-- ADDRESS -->
                        <div class="mb-3">

                            <label class="form-label">
                                Address
                            </label>

                            <textarea
                                name="address"
                                class="<?= form_error('address') ? 'form-control is-invalid' : 'form-control'; ?>"
                                rows="2"
                                maxlength="255"
                                placeholder="Complete Address"
                                required><?= set_value('address'); ?></textarea>
                            <?php if (form_error('address')): ?>
                                <div class="invalid-feedback d-block inline-validation-feedback server-validation-feedback"><?= htmlspecialchars(strip_tags(form_error('address')), ENT_QUOTES, 'UTF-8'); ?></div>
                            <?php endif; ?>

                        </div>


                        <!-- PASSWORD -->
                        <div class="row">

                            <div class="col-md-6 mb-3">

                                <label class="form-label">
                                    Password
                                </label>

                                <input
                                    type="password"
                                    name="password"
                                    class="<?= form_error('password') ? 'form-control is-invalid' : 'form-control'; ?>"
                                    placeholder="Minimum 8 characters"
                                    minlength="8"
                                    maxlength="72"
                                    autocomplete="new-password"
                                    required>
                                <?php if (form_error('password')): ?>
                                    <div class="invalid-feedback d-block inline-validation-feedback server-validation-feedback"><?= htmlspecialchars(strip_tags(form_error('password')), ENT_QUOTES, 'UTF-8'); ?></div>
                                <?php endif; ?>

                            </div>


                            <div class="col-md-6 mb-3">

                                <label class="form-label">
                                    Confirm Password
                                </label>

                                <input
                                    type="password"
                                    name="confirm_password"
                                    class="<?= form_error('confirm_password') ? 'form-control is-invalid' : 'form-control'; ?>"
                                    placeholder="Confirm Password"
                                    minlength="8"
                                    maxlength="72"
                                    autocomplete="new-password"
                                    required>
                                <?php if (form_error('confirm_password')): ?>
                                    <div class="invalid-feedback d-block inline-validation-feedback server-validation-feedback"><?= htmlspecialchars(strip_tags(form_error('confirm_password')), ENT_QUOTES, 'UTF-8'); ?></div>
                                <?php endif; ?>

                            </div>

                        </div>


                        <!-- SUBMIT -->
                        <button
                            type="submit"
                            name="register"
                            value="1"
                            class="btn btn-primary w-100">

                            Create Account

                        </button>


                    </form>


                    <!-- LOGIN -->
                    <div class="text-center mt-3">

                        Already have an account?

                        <a href="<?= base_url('login'); ?>">
                            Login
                        </a>

                    </div>


                    <!-- HOME -->
                    <div class="text-center mt-2">

                        <a href="<?= base_url('home'); ?>">
                            Back to Homepage
                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<script src="<?= base_url('assets/js/form-validation.js'); ?>"></script>

<script>
    alertify.set('notifier', 'delay', 3);
    alertify.set('notifier', 'position', 'top-right');


    // Success message
    <?php if ($this->session->flashdata('success')): ?>

        alertify.success(<?= json_encode(strip_tags($this->session->flashdata('success'))); ?>);

    <?php endif; ?>

</script>

</script>


</body>
</html>