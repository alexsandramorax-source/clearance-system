<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First Administrator Setup | School Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css">
</head>
<body class="auth-page">
    <main class="auth-card">
        <h1 class="auth-title">First Administrator</h1>
        <p class="auth-subtitle">Create the first administrator login for this system.</p>

        <div class="alert alert-warning" role="note">
            This one-time setup closes automatically after an administrator account is created.
            Use it only while you are setting up the system.
        </div>

        <form method="post" action="<?= base_url('admin/setup'); ?>">
            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                   value="<?= $this->security->get_csrf_hash(); ?>">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="admin-id">Admin ID</label>
                    <input id="admin-id" type="text" name="admin_id" class="form-control"
                           minlength="3" maxlength="50" pattern="[A-Za-z0-9_\-]+"
                           value="<?= set_value('admin_id'); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="admin-email">Email</label>
                    <input id="admin-email" type="email" name="email" class="form-control"
                           maxlength="150" value="<?= set_value('email'); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="admin-first-name">First Name</label>
                    <input id="admin-first-name" type="text" name="first_name" class="form-control"
                           minlength="2" maxlength="100" value="<?= set_value('first_name'); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="admin-last-name">Last Name</label>
                    <input id="admin-last-name" type="text" name="last_name" class="form-control"
                           minlength="2" maxlength="100" value="<?= set_value('last_name'); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="admin-password">Password</label>
                    <input id="admin-password" type="password" name="password" class="form-control"
                           minlength="8" maxlength="72" autocomplete="new-password" required>
                    <small class="form-text">Use at least 8 characters.</small>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="admin-confirm-password">Confirm Password</label>
                    <input id="admin-confirm-password" type="password" name="confirm_password"
                           class="form-control" minlength="8" maxlength="72" autocomplete="new-password" required>
                </div>
            </div>
            <button type="submit" name="create_first_admin" value="1" class="btn btn-primary w-100">
                Create First Admin Account
            </button>
        </form>

        <div class="auth-links">
            <a href="<?= base_url('login'); ?>">Back to Admin Login</a>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
    <script src="<?= base_url('assets/js/form-validation.js'); ?>"></script>
    <?php if (!empty($error)): ?>
    <script>
        alertify.set('notifier', 'position', 'top-right');
        alertify.error(<?= json_encode(strip_tags($error)); ?>);
    </script>
    <?php endif; ?>
</body>
</html>
