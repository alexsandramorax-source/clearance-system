<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logged Out | School Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
</head>
<body class="logout-page">
    <main class="logout-shell">
        <section class="logout-card" aria-labelledby="logout-heading">
            <div class="logout-icon" aria-hidden="true">✓</div>
            <p class="logout-eyebrow">SCHOOL CLEARANCE</p>
            <h1 id="logout-heading">You have been logged out</h1>
            <p class="logout-message">Your session has ended safely. You can sign in again whenever you’re ready.</p>
            <div class="logout-actions">
                <a href="<?= base_url('login'); ?>" class="btn btn-primary">Log in again</a>
                <a href="<?= base_url('home'); ?>" class="btn logout-home-link">Back to homepage</a>
            </div>
        </section>
    </main>
</body>
</html>
