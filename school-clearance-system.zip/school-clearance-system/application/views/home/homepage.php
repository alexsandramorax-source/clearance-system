<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Capitol University | School Clearance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>?v=<?= filemtime(FCPATH . 'assets/css/style.css'); ?>">
</head>
<body class="home-page">
    <div class="home-admin">
        <a href="<?= base_url('login'); ?>">♙ Admin</a>
    </div>
    <main class="home-hero">
        <header class="home-heading">
            <div class="home-seal" aria-label="Capitol University">CU<br>1971</div>
            <div>
                <h1>Capitol University</h1>
                <p>Manage your school clearance conveniently and track your<br class="d-none d-md-block"> clearance status online.</p>
            </div>
        </header>
        <section class="home-showcase" aria-label="School clearance portal">
            <div class="home-photo" role="img" aria-label="Capitol University graduates"></div>
            <div class="home-cta">
                <h2>School Clearance</h2>
                <a href="<?= base_url('login'); ?>">Log in</a>
                <a href="<?= base_url('register'); ?>">Register</a>
            </div>
        </section>
    </main>
</body>
</html>
