<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

/*
|--------------------------------------------------------------------------
| HOME
|--------------------------------------------------------------------------
*/

$route['home'] = 'Home/index';


/*
|--------------------------------------------------------------------------
| AUTHENTICATION
|--------------------------------------------------------------------------
*/

$route['login'] = 'AuthController/login';
$route['register'] = 'AuthController/register';
$route['admin/setup'] = 'AuthController/setup_admin';
$route['logout'] = 'AuthController/logout';


/*
|--------------------------------------------------------------------------
| STUDENT
|--------------------------------------------------------------------------
*/

$route['student'] = 'StudentController/index';
$route['student/dashboard'] = 'StudentController/index';
$route['student/profile'] = 'StudentController/profile';
$route['student/profile/edit'] = 'StudentController/edit_profile';
$route['student/profile/update'] = 'StudentController/update_profile';
$route['student/profile/photo'] = 'StudentController/upload_profile_photo';

/*
|--------------------------------------------------------------------------
| ADMIN
|--------------------------------------------------------------------------
*/
$route['admin'] = 'AdminController/index';
$route['admin/dashboard'] = 'AdminController/dashboard';
$route['admin/requests'] = 'AdminController/requests_page';
$route['admin/students'] = 'AdminController/students_page';
$route['admin/admins'] = 'AdminController/admins_page';
$route['admin/import-students'] = 'AdminController/import_page';
$route['admin/email-students'] = 'AdminController/email_page';
$route['admin/request/update/(:num)'] = 'AdminController/update_request/$1';
$route['admin/accounts/create'] = 'AdminController/create_account';
$route['admin/students/export'] = 'AdminController/export_students';
$route['admin/students/template'] = 'AdminController/download_student_template';
$route['admin/students/import'] = 'AdminController/import_students';
$route['admin/students/email'] = 'AdminController/email_students';


/*
|--------------------------------------------------------------------------
| CLEARANCE
|--------------------------------------------------------------------------
*/

$route['student/requirements'] = 'ClearanceController/requirements';
$route['student/status'] = 'ClearanceController/status';
$route['student/request'] = 'ClearanceController/request';
$route['student/request/delete/(:num)'] = 'ClearanceController/delete_request/$1';

/*
|--------------------------------------------------------------------------
| EDIT
|--------------------------------------------------------------------------
*/

$route['student/request'] =
    'ClearanceController/request';

$route['student/status'] =
    'ClearanceController/status';

$route['student/request/edit/(:num)'] =
    'ClearanceController/edit/$1';

$route['student/request/delete/(:num)'] =
    'ClearanceController/delete_request/$1';