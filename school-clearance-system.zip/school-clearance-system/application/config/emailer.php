<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol']    = 'smtp';
$config['smtp_host']   = 'smtp.gmail.com';
$config['smtp_user']   = 'alexsandramorax@gmail.com'; // Replace with your real Gmail address
$config['smtp_pass']   = 'ztgdjyhrbtygeigc';   // Replace with your 16-character App Password (no spaces)
$config['smtp_port']   = 587;
$config['smtp_crypto'] = 'tls';
$config['mailtype']    = 'html';
$config['charset']     = 'utf-8';
$config['newline']     = "\r\n";
$config['crlf']        = "\r\n";
$config['wordwrap']    = TRUE;

// Required for XAMPP / WAMP / Localhost to bypass SSL Certificate Errors
$config['smtp_conn_options'] = array(
    'ssl' => array(
        'verify_peer'      => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);