<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// SMTP settings for outgoing mail.
//
// Use a Google App Password here, never your regular Google account password.
// Create one at https://myaccount.google.com/apppasswords (requires 2-Step
// Verification). It is 16 characters and Gmail shows it in groups of four.
//
// This file is listed in .gitignore so these values stay out of version
// control. If you clone this project somewhere else, fill them in again.

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.gmail.com';
$config['smtp_user'] = 'alexsandramorax@gmail.com';
$config['smtp_pass'] = 'ztgdjyhrbtygeigc';
$config['smtp_port'] = 587;
$config['smtp_crypto'] = 'tls';
$config['smtp_timeout'] = 30;
$config['smtp_keepalive'] = FALSE;
$config['mailtype'] = 'text';
$config['charset'] = 'UTF-8';
$config['newline'] = "\r\n";
$config['crlf'] = "\r\n";
$config['wordwrap'] = TRUE;
$config['validate'] = TRUE;
$config['from_email'] = 'alexsandramorax@gmail.com';
$config['from_name'] = trim(getenv('SCHOOL_CLEARANCE_FROM_NAME') ?: 'School Clearance');