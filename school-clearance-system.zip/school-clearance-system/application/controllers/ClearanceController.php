<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ClearanceController extends CI_Controller
{
    private $validation_student_id;
    private $validation_request_id;

    public function __construct()
    {
        parent::__construct();

        $this->load->model(
            'Clearance_Model'
        );

        $this->load->model(
            'Student_Model'
        );
    }


    // check log in

    private function check_login()
    {

        if (!$this->session->userdata('logged_in')) {

            $this->session->set_flashdata(
                'error',
                'Please login first.'
            );

            redirect('login');
        }


        if (
            $this->session->userdata('role')
            !=
            'student'
        ) {

            redirect('home');
        }

        if ($this->session->userdata('profile_photo') === NULL) {
            $student = $this->Student_Model->get_by_user_id(
                $this->session->userdata('user_id')
            );
            $this->session->set_userdata(
                'profile_photo',
                $student ? $student->profile_photo : ''
            );
        }
    }


    // clearance requirements
    public function requirements()
    {

        $this->check_login();


        $data['requirements'] =
            $this->Clearance_Model
                ->get_requirements();


        $this->load->view(
            'student/requirements',
            $data
        );
    }

    public function valid_school_year($school_year)
    {
        if (!is_string($school_year)
            || !preg_match('/^[0-9]{4}-[0-9]{4}$/', $school_year)) {
            return FALSE;
        }

        list($start_year, $end_year) = explode('-', $school_year);
        return (int) $end_year === (int) $start_year + 1;
    }

    public function unique_clearance_combination($semester)
    {
        $school_year = $this->input->post('school_year');
        if (!is_string($school_year)) {
            return FALSE;
        }
        $school_year = trim($school_year);
        if (!$this->validation_student_id
            || !$this->valid_school_year($school_year)
            || !is_string($semester)) {
            return FALSE;
        }

        $requests = $this->Clearance_Model->get_student_requests(
            $this->validation_student_id
        );
        foreach ($requests as $existing) {
            if ($this->validation_request_id
                && (int) $existing->id === (int) $this->validation_request_id) {
                continue;
            }

            if ($existing->school_year === $school_year
                && $existing->semester === $semester
                && $existing->status !== 'Rejected') {
                return FALSE;
            }
        }

        return TRUE;
    }


    //request clearance
    public function request()
    {

        $this->check_login();


        $student =
            $this->Student_Model
                ->get_by_user_id(
                    $this->session
                        ->userdata('user_id')
                );


        if (!$student) {

            $this->session->set_flashdata(
                'error',
                'Student information was not found.'
            );

            redirect('student/dashboard');
        }


        if ($this->input->method(TRUE) === 'POST') {
            $this->validation_student_id = (int) $student->id;
            $this->validation_request_id = NULL;


            $this->form_validation
                ->set_rules(
                    'school_year',
                    'School Year',
                    'required|trim|callback_valid_school_year'
                );


            $this->form_validation
                ->set_rules(
                    'semester',
                    'Semester',
                    'required|trim|in_list[1st Semester,2nd Semester,Summer]|callback_unique_clearance_combination'
                );

            $this->form_validation->set_message(
                'valid_school_year',
                'Enter a consecutive school year, such as 2025-2026.'
            );
            $this->form_validation->set_message(
                'unique_clearance_combination',
                'You already have a clearance request for this school year and semester.'
            );

            if (
                $this->form_validation->run()
                ==
                FALSE
            ) {

                $this->session
                    ->set_flashdata(
                        'error',
                        validation_errors()
                    );

                redirect(
                    'student/request'
                );
            }

            $school_year = $this->input->post('school_year', TRUE);

            $request_data = array(

                'student_id' =>
                    $student->id,

                'school_year' =>
                    $school_year,

                'semester' =>
                    $this->input
                        ->post(
                            'semester',
                            TRUE
                        ),

                'status' =>
                    'Pending',

                'remarks' =>
                    NULL

            );


            $this->db->trans_start();


            $this->Clearance_Model
                ->create_request(
                    $request_data
                );


            $request_id =
                $this->db->insert_id();


            // Get all departments

            $departments =
                $this->Clearance_Model
                    ->get_departments();


            // Create Pending status
            // for every department

            foreach (
                $departments
                as $department
            ) {

                $this->Clearance_Model
                    ->create_department_status(
                        $request_id,
                        $department->id
                    );
            }


            $this->db->trans_complete();


            if (
                $this->db->trans_status()
                ===
                FALSE
            ) {

                $this->session
                    ->set_flashdata(
                        'error',
                        'Failed to submit clearance request.'
                    );

                redirect(
                    'student/request'
                );
            }


            $this->session
                ->set_flashdata(
                    'success',
                    'Clearance request submitted successfully.'
                );

            redirect(
                'student/status'
            );
        }


        $this->load->view(
            'student/request'
        );
    }


   // view status
    public function status()
    {

        $this->check_login();


        $student =
            $this->Student_Model
                ->get_by_user_id(
                    $this->session
                        ->userdata('user_id')
                );

        if (!$student) {
            $this->session->set_flashdata('error', 'Student information was not found.');
            redirect('student/dashboard');
        }


        $data['requests'] =
            $this->Clearance_Model
                ->get_student_requests(
                    $student->id
                );


        $data['latest_request'] =
            $this->Clearance_Model
                ->get_latest_request(
                    $student->id
                );

        $data['latest_evaluation'] = $data['latest_request']
            ? $this->clearanceevaluator->evaluate($data['latest_request']->status)
            : NULL;


        $data['statuses'] = array();


        if (
            $data['latest_request']
        ) {

            $data['statuses'] =
                $this->Clearance_Model
                    ->get_status(
                        $data['latest_request']->id
                    );
        }

        $this->load->view(
            'student/status',
            $data
        );
    }


   // delete request
    public function delete_request(
        $request_id
    )
    {

        $this->check_login();
        if ($this->input->method(TRUE) !== 'POST') {
            redirect('student/status');
        }


        $student =
            $this->Student_Model
                ->get_by_user_id(
                    $this->session
                        ->userdata('user_id')
                );

        if (!$student) {
            $this->session->set_flashdata('error', 'Student information was not found.');
            redirect('student/dashboard');
        }


        $request =
            $this->Clearance_Model
                ->get_request(
                    $request_id,
                    $student->id
                );


        if (!$request) {

            $this->session
                ->set_flashdata(
                    'error',
                    'Clearance request not found.'
                );

            redirect(
                'student/status'
            );
        }


        // Student can delete only
        // pending requests

        if (
            $request->status
            !=
            'Pending'
        ) {

            $this->session
                ->set_flashdata(
                    'error',
                    'Only pending requests can be deleted.'
                );

            redirect(
                'student/status'
            );
        }


        if (
            $this->Clearance_Model
                ->delete_request(
                    $request_id,
                    $student->id
                )
        ) {

            $this->session
                ->set_flashdata(
                    'success',
                    'Clearance request deleted successfully.'
                );

        } else {

            $this->session
                ->set_flashdata(
                    'error',
                    'Failed to delete request.'
                );
        }


        redirect(
            'student/status'
        );
    }
// edit clearance request

public function edit($request_id)
{
    $this->check_login();


    // Get logged-in student

    $student =
        $this->Student_Model
            ->get_by_user_id(
                $this->session
                    ->userdata('user_id')
            );

    if (!$student) {
        $this->session->set_flashdata('error', 'Student information was not found.');
        redirect('student/dashboard');
    }


    // Find request belonging to student

    $request =
        $this->Clearance_Model
            ->get_request(
                $request_id,
                $student->id
            );


    if (!$request) {

        $this->session
            ->set_flashdata(
                'error',
                'Clearance request not found.'
            );

        redirect(
            'student/status'
        );
    }


    // Only Pending requests can be edited

    if (
        $request->status
        !=
        'Pending'
    ) {

        $this->session
            ->set_flashdata(
                'error',
                'Only pending requests can be edited.'
            );

        redirect(
            'student/status'
        );
    }

// update

    if ($this->input->method(TRUE) === 'POST') {
        $this->validation_student_id = (int) $student->id;
        $this->validation_request_id = (int) $request->id;


        // Validation

        $this->form_validation
            ->set_rules(
                'school_year',
                'School Year',
                'required|trim|callback_valid_school_year'
            );


        $this->form_validation
            ->set_rules(
                'semester',
                'Semester',
                'required|trim|in_list[1st Semester,2nd Semester,Summer]|callback_unique_clearance_combination'
            );

        $this->form_validation->set_message(
            'valid_school_year',
            'Enter a consecutive school year, such as 2025-2026.'
        );
        $this->form_validation->set_message(
            'unique_clearance_combination',
            'You already have a clearance request for this school year and semester.'
        );

        if (
            $this->form_validation
                ->run()
                ==
                FALSE
        ) {

            $this->session
                ->set_flashdata(
                    'error',
                    validation_errors()
                );

            redirect(
                'student/request/edit/'
                . $request_id
            );
        }

        // New values

        $school_year =
            $this->input
                ->post(
                    'school_year',
                    TRUE
                );


        $semester =
            $this->input
                ->post(
                    'semester',
                    TRUE
                );


      //update data 

        $data = array(

            'school_year' =>
                $school_year,

            'semester' =>
                $semester

        );


        $updated =
            $this->Clearance_Model
                ->update_request(
                    $request_id,
                    $student->id,
                    $data
                );


        if ($updated) {

            $this->session
                ->set_flashdata(
                    'success',
                    'Clearance request updated successfully.'
                );

        } else {

            $this->session
                ->set_flashdata(
                    'error',
                    'No changes were made or update failed.'
                );
        }


        redirect(
            'student/status'
        );
    }

//display edit page

    $data['request'] =
        $request;


    $this->load->view(
        'student/edit_request',
        $data
    );
}
}