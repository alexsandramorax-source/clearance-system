    <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminController extends CI_Controller
{
    private $validated_email_recipients = array();

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Admin_Model');
        $this->load->model('User_Model');
        $this->load->model('Student_Model');
    }

    private function check_admin()
    {
        if (!$this->session->userdata('logged_in')) {
            $this->session->set_flashdata('error', 'Please login first.');
            redirect('login');
        }

        if ($this->session->userdata('role') !== 'admin') {
            $this->session->set_flashdata('error', 'Administrator access is required.');
            redirect('student/dashboard');
        }
    }

    public function index()
    {
        redirect('admin/dashboard');
    }

    public function dashboard()
    {
        $this->render_admin_page('dashboard');
    }

    public function requests_page()
    {
        $this->render_admin_page('requests');
    }

    public function students_page()
    {
        $this->render_admin_page('students');
    }

    public function admins_page()
    {
        $this->render_admin_page('admins');
    }

    public function import_page()
    {
        $this->render_admin_page('import');
    }

    public function email_page()
    {
        $this->render_admin_page('email');
    }

    private function render_admin_page($section)
    {
        $this->check_admin();

        $page_details = array(
            'dashboard' => array('Administrator Dashboard', 'Review clearance activity at a glance.'),
            'requests' => array('Clearance Requests', 'Review and update student clearance requests.'),
            'students' => array('Student Accounts', 'Review recently added student accounts.'),
            'admins' => array('Manage Admins', 'Create administrator accounts for the clearance system.'),
            'import' => array('Import Students', 'Add or update student accounts from a spreadsheet.'),
            'email' => array('Email Students', 'Send a private message to selected students or the full roster.')
        );
        if (!isset($page_details[$section])) {
            show_404();
        }

        $data = array(
            'admin_section' => $section,
            'admin_page_title' => $page_details[$section][0],
            'admin_page_description' => $page_details[$section][1]
        );

        if ($section === 'dashboard') {
            $data['counts'] = $this->Admin_Model->get_status_counts();
            $data['clearance_chart_json'] = json_encode(
                array(
                    'labels' => array_keys($data['counts']),
                    'counts' => array_values($data['counts'])
                ),
                JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
            );
        } elseif ($section === 'requests') {
            $data['requests'] = $this->Admin_Model->get_requests();
            foreach ($data['requests'] as $request) {
                $request->evaluation = $this->clearanceevaluator->evaluate($request->status);
            }
        } elseif ($section === 'students') {
            $data['student_accounts'] = $this->Student_Model->get_recent_student_accounts();
            $data['student_account_count'] = $this->Student_Model->count_student_accounts();
        } elseif ($section === 'email') {
            $data['email_recipients'] = $this->Student_Model->get_student_email_recipients();
            $email_config = $this->load_student_email_config();
            $data['email_configured'] = $this->is_student_email_configured($email_config);
        }

        $this->load->view('admin/dashboard', $data);
    }

    public function email_students()
    {
        $this->check_admin();

        if ($this->input->method(TRUE) !== 'POST') {
            redirect('admin/email-students');
        }

        $email_config = $this->load_student_email_config();
        if (!$this->is_student_email_configured($email_config)) {
            $this->session->set_flashdata(
                'error',
                'Student email is not configured. Set the SMTP environment variables shown on this page and restart Apache.'
            );
            $this->session->set_flashdata('student_email_open', TRUE);
            redirect('admin/email-students');
        }

        $sender_email = $email_config['from_email'];
        $sender_name = $email_config['from_name'];
        unset($email_config['from_email'], $email_config['from_name']);

        $this->form_validation->set_rules(
            'subject',
            'Subject',
            'required|trim|max_length[150]|callback_valid_email_subject'
        );
        $this->form_validation->set_rules(
            'message',
            'Message',
            'required|trim|max_length[5000]'
        );
        $this->form_validation->set_rules(
            'send_to_all',
            'Recipients',
            'callback_valid_email_recipient_selection'
        );
        $this->form_validation->set_message(
            'valid_email_subject',
            'The subject must not contain line breaks.'
        );
        $this->form_validation->set_message(
            'valid_email_recipient_selection',
            'Choose all students or select at least one valid student.'
        );
        if (!$this->form_validation->run()) {
            $this->session->set_flashdata('error', strip_tags(validation_errors(' ')));
            $this->session->set_flashdata('student_email_open', TRUE);
            redirect('admin/email-students');
        }

        $recipients = $this->validated_email_recipients;

        $this->load->library('fileuploader');
        $attachment = $this->fileuploader->upload_email_attachment('email_attachment');
        if (empty($attachment['success'])) {
            $this->session->set_flashdata('error', $attachment['message']);
            $this->session->set_flashdata('student_email_open', TRUE);
            redirect('admin/email-students');
        }

        $subject = $this->input->post('subject', TRUE);
        $message = $this->input->post('message', TRUE);
        $this->load->library('email');

        $sent_count = 0;
        $failed_student_ids = array();
        try {
            foreach ($recipients as $recipient) {
                $this->email->initialize($email_config);
                $this->email->set_newline("\r\n");
                $this->email->set_crlf("\r\n");
                $this->email->from(
                    $sender_email,
                    $sender_name
                );
                $this->email->to($recipient->email);
                $this->email->subject($subject);
                $this->email->message($message);

                if (!empty($attachment['path'])
                    && !$this->email->attach($attachment['path'])) {
                    $failed_student_ids[] = $recipient->student_id;
                    $this->email->clear(TRUE);
                    continue;
                }

                if ($this->email->send()) {
                    $sent_count++;
                } else {
                    $failed_student_ids[] = $recipient->student_id;
                    log_message(
                        'error',
                        'Could not send an admin email to student ID ' . $recipient->student_id . '.'
                    );
                }
                $this->email->clear(TRUE);
            }
        } finally {
            $this->email->clear(TRUE);
            if (!empty($attachment['path'])
                && is_file($attachment['path'])
                && !unlink($attachment['path'])) {
                log_message('error', 'Could not remove a temporary student email attachment.');
            }
        }

        if (empty($failed_student_ids)) {
            $this->session->set_flashdata(
                'success',
                'Email sent individually to ' . $sent_count . ' student(s). Student addresses were not shared with other recipients.'
            );
        } elseif ($sent_count > 0) {
            $this->session->set_flashdata(
                'error',
                'Email sent to ' . $sent_count . ' student(s), but failed for Student ID(s): '
                    . implode(', ', $failed_student_ids)
                    . '. Check the SMTP configuration before retrying.'
            );
            $this->session->set_flashdata('student_email_open', TRUE);
        } else {
            $this->session->set_flashdata(
                'error',
                'The email could not be sent to any selected students. Check the SMTP configuration and try again.'
            );
            $this->session->set_flashdata('student_email_open', TRUE);
        }

        redirect('admin/email-students');
    }

    private function load_student_email_config()
    {
        $this->config->load('email', TRUE);
        $email_config = $this->config->item('email');
        return is_array($email_config) ? $email_config : array();
    }

    public function valid_email_subject($subject)
    {
        return is_string($subject)
            && preg_match('/[\r\n]/', $subject) !== 1;
    }

    public function valid_email_recipient_selection($send_to_all)
    {
        if ($send_to_all !== NULL && !is_string($send_to_all)) {
            return FALSE;
        }

        $all_recipients = $this->Student_Model->get_student_email_recipients();
        if ($send_to_all === '1') {
            $this->validated_email_recipients = $all_recipients;
            return !empty($this->validated_email_recipients);
        }

        if ($send_to_all !== NULL && $send_to_all !== '') {
            return FALSE;
        }

        $selected_ids = $this->input->post('student_user_ids');
        if (!is_array($selected_ids) || empty($selected_ids)) {
            return FALSE;
        }

        $recipients_by_id = array();
        foreach ($all_recipients as $recipient) {
            $recipients_by_id[(string) $recipient->id] = $recipient;
        }

        $selected_recipients = array();
        foreach ($selected_ids as $selected_id) {
            if (!is_scalar($selected_id)
                || !ctype_digit((string) $selected_id)
                || !isset($recipients_by_id[(string) $selected_id])) {
                return FALSE;
            }
            $selected_recipients[(string) $selected_id] = $recipients_by_id[(string) $selected_id];
        }

        $this->validated_email_recipients = array_values($selected_recipients);
        return !empty($this->validated_email_recipients);
    }

    private function is_student_email_configured($email_config)
    {
        return !empty($email_config['smtp_host'])
            && !empty($email_config['smtp_user'])
            && !empty($email_config['smtp_pass'])
            && !empty($email_config['from_email'])
            && filter_var($email_config['from_email'], FILTER_VALIDATE_EMAIL)
            && in_array($email_config['smtp_crypto'], array('tls', 'ssl'), TRUE)
            && $email_config['smtp_port'] > 0
            && $email_config['smtp_port'] <= 65535;
    }

    public function update_request($request_id)
    {
        $this->check_admin();

        if ($this->input->method(TRUE) !== 'POST') {
            redirect('admin/requests');
        }

        $this->form_validation->set_rules(
            'status',
            'Status',
            'required|in_list[Pending,Processing,Cleared,Rejected]'
        );
        $this->form_validation->set_rules(
            'remarks',
            'Remarks',
            'trim|max_length[1000]'
        );

        if (!$this->form_validation->run()) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('admin/requests');
        }

        $updated = $this->Admin_Model->update_request(
            (int) $request_id,
            $this->input->post('status', TRUE),
            $this->input->post('remarks', TRUE)
        );

        $this->session->set_flashdata(
            $updated ? 'success' : 'error',
            $updated ? 'Clearance request updated successfully.' : 'The clearance request could not be updated.'
        );
        redirect('admin/requests');
    }

    public function max_bytes($value)
    {
        return !is_string($value) || strlen($value) <= 72;
    }

    public function create_account()
    {
        $this->check_admin();

        if ($this->input->method(TRUE) !== 'POST') {
            redirect('admin/admins');
        }

        $this->form_validation->set_rules(
            'admin_id',
            'Admin ID',
            'required|trim|alpha_dash|min_length[3]|max_length[50]|is_unique[users.student_id]',
            array('is_unique' => 'Admin ID is already in use.')
        );
        $this->form_validation->set_rules(
            'first_name',
            'First Name',
            'required|trim|min_length[2]|max_length[100]'
        );
        $this->form_validation->set_rules(
            'last_name',
            'Last Name',
            'required|trim|min_length[2]|max_length[100]'
        );
        $this->form_validation->set_rules(
            'email',
            'Email',
            'required|trim|valid_email|max_length[150]|is_unique[users.email]',
            array('is_unique' => 'Email address is already in use.')
        );
        $this->form_validation->set_rules(
            'password',
            'Password',
            'required|min_length[8]|max_length[72]|callback_max_bytes'
        );
        $this->form_validation->set_rules(
            'confirm_password',
            'Confirm Password',
            'required|matches[password]'
        );

        $this->form_validation->set_message('max_bytes', 'Passwords must not exceed 72 bytes.');

        if (!$this->form_validation->run()) {
            $this->session->set_flashdata('error', validation_errors());
            $this->session->set_flashdata('admin_form_open', TRUE);
            redirect('admin/admins');
        }

        $admin_id = $this->input->post('admin_id', TRUE);
        $email = $this->input->post('email', TRUE);

        $created = $this->User_Model->create_user(array(
            'student_id' => $admin_id,
            'first_name' => $this->input->post('first_name', TRUE),
            'last_name' => $this->input->post('last_name', TRUE),
            'email' => $email,
            'password' => password_hash(
                $this->input->post('password'),
                PASSWORD_DEFAULT
            ),
            'role' => 'admin'
        ));

        $this->session->set_flashdata(
            $created ? 'success' : 'error',
            $created
                ? 'Administrator account created successfully.'
                : 'Administrator account could not be created. Please try again.'
        );
        if (!$created) {
            $this->session->set_flashdata('admin_form_open', TRUE);
        }
        redirect('admin/admins');
    }

    public function export_students()
    {
        $this->check_admin();

        $headers = array(
            'student_id',
            'first_name',
            'last_name',
            'email',
            'password',
            'course',
            'year_level',
            'contact_number',
            'address'
        );
        $rows = $this->Student_Model->get_student_export_rows();
        $this->download_student_workbook(
            $headers,
            $rows,
            'students-' . date('Y-m-d') . '.xlsx'
        );
    }

    public function download_student_template()
    {
        $this->check_admin();

        $headers = array(
            'student_id',
            'first_name',
            'last_name',
            'email',
            'password',
            'course',
            'year_level',
            'contact_number',
            'address'
        );
        $this->download_student_workbook(
            $headers,
            array(),
            'student-import-template.xlsx'
        );
    }

    private function download_student_workbook($headers, $rows, $filename)
    {
        $this->load->library('studentspreadsheetexporter');
        $export_directory = APPPATH . 'cache' . DIRECTORY_SEPARATOR . 'uploads';
        if (!is_dir($export_directory) || !is_writable($export_directory)) {
            show_error('The student export could not be generated.', 500);
            return;
        }

        $temporary_path = tempnam($export_directory, 'student-export-');
        if ($temporary_path === FALSE
            || realpath(dirname($temporary_path)) !== realpath($export_directory)) {
            if ($temporary_path !== FALSE && is_file($temporary_path)) {
                unlink($temporary_path);
            }
            show_error('The student export could not be generated.', 500);
            return;
        }

        $export = $this->studentspreadsheetexporter->write_xlsx(
            $temporary_path,
            $headers,
            $rows
        );
        if (empty($export['success'])) {
            unlink($temporary_path);
            log_message('error', 'Student XLSX export failed: ' . $export['message']);
            show_error($export['message'], 500);
            return;
        }

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');
        if (readfile($temporary_path) === FALSE) {
            log_message('error', 'Could not stream the generated student XLSX export.');
        }

        if (!unlink($temporary_path)) {
            log_message('error', 'Could not remove a generated student XLSX export from the private upload directory.');
        }
        exit;
    }

    public function import_students()
    {
        $this->check_admin();

        if ($this->input->method(TRUE) !== 'POST') {
            redirect('admin/import-students');
        }

        $this->load->library('fileuploader');
        $upload = $this->fileuploader->upload_spreadsheet('student_file');
        if (empty($upload['success'])) {
            $this->session->set_flashdata('error', $upload['message']);
            $this->session->set_flashdata('student_import_open', TRUE);
            redirect('admin/import-students');
        }

        $this->load->library('studentspreadsheetimporter');
        $import = $this->studentspreadsheetimporter->read(
            $upload['full_path'],
            $upload['extension']
        );
        if (is_file($upload['full_path']) && !unlink($upload['full_path'])) {
            log_message('error', 'Could not remove a processed student import file from the private upload directory.');
        }

        if (empty($import['success'])) {
            $this->session->set_flashdata('error', $import['message']);
            $this->session->set_flashdata('student_import_open', TRUE);
            redirect('admin/import-students');
        }

        $seen_ids = array();
        $seen_emails = array();
        $prepared_rows = array();
        $student_rows = $import['students'];
        foreach ($student_rows as $index => $row) {
            $row_number = $index + 2;
            $student_id = $row['student_id'];
            $email = strtolower($row['email']);
            $existing_user = $this->User_Model->get_by_student_id($student_id);
            $existing_student = NULL;
            if ($existing_user && $existing_user->role === 'student') {
                $existing_student = $this->Student_Model->get_by_user_id($existing_user->id);
            }

            if (($existing_user && $existing_user->role !== 'student')
                || ($existing_user && !$existing_student)) {
                $this->session->set_flashdata(
                    'error',
                    'Row ' . $row_number . ' conflicts with an existing account or has no student profile. No changes were saved.'
                );
                $this->session->set_flashdata('student_import_open', TRUE);
                redirect('admin/import-students');
            }

            $validation_data = $row;
            $validation_data['email'] = $email;
            $this->form_validation->reset_validation();
            $this->form_validation->validation_data = array();
            $this->form_validation->set_data($validation_data);
            $this->form_validation->set_rules(
                'student_id',
                'Student ID',
                'required|trim|regex_match[/^[0-9]{3,50}$/]'
            );
            $this->form_validation->set_rules(
                'first_name',
                'First Name',
                'required|trim|regex_match[/^[\p{L}][\p{L} .\'’-]{1,99}$/u]'
            );
            $this->form_validation->set_rules(
                'last_name',
                'Last Name',
                'required|trim|regex_match[/^[\p{L}][\p{L} .\'’-]{1,99}$/u]'
            );
            $this->form_validation->set_rules(
                'email',
                'Email',
                'required|trim|valid_email|max_length[150]'
            );
            $password_rules = $existing_user
                ? 'max_length[72]|callback_max_bytes'
                : 'required|min_length[8]|max_length[72]|callback_max_bytes';
            $this->form_validation->set_rules('password', 'Password', $password_rules);
            $this->form_validation->set_rules(
                'course',
                'Course',
                'required|trim|max_length[150]'
            );
            $this->form_validation->set_rules(
                'year_level',
                'Year Level',
                'required|trim|in_list[1st Year,2nd Year,3rd Year,4th Year]'
            );
            $this->form_validation->set_rules(
                'contact_number',
                'Contact Number',
                'required|trim|regex_match[/^[0-9+() -]{7,30}$/]'
            );
            $this->form_validation->set_rules(
                'address',
                'Address',
                'required|trim|max_length[255]'
            );
            $this->form_validation->set_message(
                'max_bytes',
                'Passwords must not exceed 72 bytes.'
            );

            $row_is_valid = $this->form_validation->run();
            $row_validation_errors = strip_tags(validation_errors(' '));
            $this->form_validation->validation_data = array();
            $this->form_validation->reset_validation();
            if (!$row_is_valid) {
                $this->session->set_flashdata(
                    'error',
                    'Row ' . $row_number . ': ' . $row_validation_errors . ' No changes were saved.'
                );
                $this->session->set_flashdata('student_import_open', TRUE);
                redirect('admin/import-students');
            }

            $email_owner = $this->User_Model->get_by_email($email);
            $email_belongs_to_another_account = $email_owner
                && (!$existing_user || (int) $email_owner->id !== (int) $existing_user->id);
            if (isset($seen_ids[$student_id]) || isset($seen_emails[$email])
                || $email_belongs_to_another_account) {
                $this->session->set_flashdata(
                    'error',
                    'Row ' . $row_number . ' has a duplicate student ID or email. No changes were saved.'
                );
                $this->session->set_flashdata('student_import_open', TRUE);
                redirect('admin/import-students');
            }

            $seen_ids[$student_id] = TRUE;
            $seen_emails[$email] = TRUE;
            $prepared_rows[] = array(
                'data' => $row,
                'user' => $existing_user,
                'student' => $existing_student
            );
        }

        $added_count = 0;
        $updated_count = 0;
        $this->db->trans_begin();
        foreach ($prepared_rows as $prepared_row) {
            $row = $prepared_row['data'];
            if ($prepared_row['user']) {
                $user_data = array(
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'email' => $row['email']
                );
                if ($row['password'] !== '') {
                    $user_data['password'] = password_hash(
                        $row['password'],
                        PASSWORD_DEFAULT
                    );
                }

                $saved = $this->User_Model->update_user(
                    $prepared_row['user']->id,
                    $user_data
                );
                if ($saved) {
                    $saved = $this->Student_Model->update_student(
                        $prepared_row['student']->id,
                        array(
                            'course' => $row['course'],
                            'year_level' => $row['year_level'],
                            'contact_number' => $row['contact_number'],
                            'address' => $row['address']
                        )
                    );
                }
                if (!$saved) {
                    $this->db->trans_rollback();
                    $this->session->set_flashdata('error', 'Student update failed; no changes were saved.');
                    $this->session->set_flashdata('student_import_open', TRUE);
                    redirect('admin/import-students');
                }
                $updated_count++;
                continue;
            }

            $created = $this->User_Model->create_user(array(
                'student_id' => $row['student_id'],
                'first_name' => $row['first_name'],
                'last_name' => $row['last_name'],
                'email' => $row['email'],
                'password' => password_hash($row['password'], PASSWORD_DEFAULT),
                'role' => 'student'
            ));
            if (!$created) {
                $this->db->trans_rollback();
                $this->session->set_flashdata('error', 'Student import failed; no changes were saved.');
                $this->session->set_flashdata('student_import_open', TRUE);
                redirect('admin/import-students');
            }

            $user_id = $this->db->insert_id();
            $created_student = $this->Student_Model->create_student(array(
                'user_id' => $user_id,
                'student_id' => $row['student_id'],
                'course' => $row['course'],
                'year_level' => $row['year_level'],
                'contact_number' => $row['contact_number'],
                'address' => $row['address']
            ));

            if (!$created_student) {
                $this->db->trans_rollback();
                $this->session->set_flashdata('error', 'Student import failed; no changes were saved.');
                $this->session->set_flashdata('student_import_open', TRUE);
                redirect('admin/import-students');
            }
            $added_count++;
        }

        if ($this->db->trans_status() === FALSE || !$this->db->trans_commit()) {
            $this->db->trans_rollback();
            $this->session->set_flashdata('error', 'Student import failed; no changes were saved.');
            $this->session->set_flashdata('student_import_open', TRUE);
            redirect('admin/import-students');
        }

        $this->session->set_flashdata(
            'success',
            $added_count . ' student account(s) added and '
                . $updated_count . ' existing account(s) updated. Students omitted from this spreadsheet were left unchanged.'
        );
        redirect('admin/import-students');
    }

}
