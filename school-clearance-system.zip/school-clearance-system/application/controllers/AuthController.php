<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AuthController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        $this->load->model('User_Model');
        $this->load->model('Student_Model');
    }


   //register 

    public function register()
    {

        if ($this->session->userdata('logged_in')) {
            redirect(
                $this->session->userdata('role') === 'admin'
                    ? 'admin/dashboard'
                    : 'student/dashboard'
            );
        }


        if ($this->input->method(TRUE) === 'POST') {

            $this->form_validation->set_rules(
                'student_id',
                'Student ID',
                'required|trim|regex_match[/^[0-9]{3,50}$/]|is_unique[users.student_id]',
                array(
                    'regex_match' => 'Student ID must be numbers.',
                    'is_unique' => 'Student ID already exists.'
                )
            );

            $this->form_validation->set_rules(
                'first_name',
                'First Name',
                'required|trim|min_length[2]|max_length[100]'
            );

            $this->form_validation->set_rules(
                'last_name',
                'Last Name',
                'required|trim|min_length[2]|max_length[100]'
            );

            $this->form_validation->set_rules(
                'email',
                'Email',
                'required|trim|regex_match[/^[^@\s]+@[^@\s]+$/]|valid_email|max_length[150]|is_unique[users.email]',
                array(
                    'regex_match' => 'Email must contain @.',
                    'is_unique' => 'Email address is already registered.'
                )
            );

            $this->form_validation->set_rules(
                'password',
                'Password',
                'required|min_length[8]|max_length[72]|callback_max_bytes'
            );

            $this->form_validation->set_rules(
                'confirm_password',
                'Confirm Password',
                'required|matches[password]'
            );

            $this->form_validation->set_rules(
                'course',
                'Course',
                'required|trim|max_length[150]'
            );

            $this->form_validation->set_rules(
                'year_level',
                'Year Level',
                'required|trim|in_list[1st Year,2nd Year,3rd Year,4th Year]'
            );

            $this->form_validation->set_rules(
                'contact_number',
                'Contact Number',
                'required|trim|regex_match[/^[0-9+() -]{7,30}$/]|max_length[30]'
            );

            $this->form_validation->set_rules(
                'address',
                'Address',
                'required|trim|max_length[255]'
            );


            $this->form_validation->set_message('max_bytes', 'Passwords must not exceed 72 bytes.');

            if ($this->form_validation->run() == FALSE) {
                $this->load->view('auth/register');
                return;
            }

            $student_id = $this->input->post('student_id', TRUE);
            $email = $this->input->post('email', TRUE);

            $user_data = array(

                'student_id' => $student_id,

                'first_name' =>
                    $this->input->post('first_name', TRUE),

                'last_name' =>
                    $this->input->post('last_name', TRUE),

                'email' =>
                    $email,

                'password' =>
                    password_hash(
                        $this->input->post('password'),
                        PASSWORD_DEFAULT
                    ),

                'role' => 'student'

            );


            $this->db->trans_start();


            $this->User_Model->create_user($user_data);

            $user_id = $this->db->insert_id();


            $student_data = array(

                'user_id' => $user_id,

                'student_id' => $student_id,

                'course' =>
                    $this->input->post('course', TRUE),

                'year_level' =>
                    $this->input->post('year_level', TRUE),

                'contact_number' =>
                    $this->input->post('contact_number', TRUE),

                'address' =>
                    $this->input->post('address', TRUE)

            );


            $this->Student_Model->create_student($student_data);


            $this->db->trans_complete();


            if ($this->db->trans_status() === FALSE) {

                $this->session->set_flashdata(
                    'error',
                    'Registration failed. Please try again.'
                );

                redirect('register');

            }


            $this->session->set_flashdata(
                'success',
                'Registration successful! You can now login.'
            );

            redirect('login');
        }


        $this->load->view('auth/register');
    }


    /**
     * Form validation callback for the password rules.
     *
     * bcrypt truncates silently at 72 bytes, and CI's max_length counts
     * characters (mb_strlen), so a multibyte password such as 40 emoji is
     * 40 characters but 160 bytes. It would pass max_length[72] and then be
     * silently cut, leaving the user unable to sign in with what they typed.
     */
    public function max_bytes($str)
    {
        return is_string($str) ? strlen($str) <= 72 : TRUE;
    }


    //log in

    public function login()
    {
        if ($this->input->method(TRUE) === 'POST') {

            $this->form_validation->set_rules(
                'email',
                'Email',
                'required|trim|valid_email',
                array('valid_email' => 'Email must contain @ and be a valid email address.')
            );

            $this->form_validation->set_rules(
                'password',
                'Password',
                'required'
            );


            if ($this->form_validation->run() == FALSE) {

                $this->session->set_flashdata(
                    'error',
                    validation_errors()
                );

                redirect('login');
            }


            $email =
                $this->input->post('email', TRUE);

            $password =
                $this->input->post('password');


            $user =
                $this->User_Model->get_by_email($email);


            if (!$user) {

                $this->session->set_flashdata(
                    'error',
                    'Invalid email or password.'
                );

                redirect('login');
            }


            if (!password_verify($password, $user->password)) {

                $this->session->set_flashdata(
                    'error',
                    'Invalid email or password.'
                );

                redirect('login');
            }


            if (!in_array($user->role, array('student', 'admin'), TRUE)) {
                $this->session->set_flashdata(
                    'error',
                    'This account is not allowed to access the system.'
                );

                redirect('login');
            }


            $session_data = array(

                'user_id' =>
                    $user->id,

                'student_id' =>
                    $user->student_id,

                'first_name' =>
                    $user->first_name,

                'last_name' =>
                    $user->last_name,

                'email' =>
                    $user->email,

                'role' =>
                    $user->role,

                'logged_in' =>
                    TRUE

            );

            $this->session->unset_userdata(array(
                'user_id',
                'student_id',
                'first_name',
                'last_name',
                'email',
                'role',
                'profile_photo',
                'logged_in'
            ));
            $this->session->sess_regenerate(TRUE);

            $student = $user->role === 'student'
                ? $this->Student_Model->get_by_user_id($user->id)
                : NULL;
            $session_data['profile_photo'] = $student
                ? $student->profile_photo
                : '';

            $this->session->set_userdata(
                $session_data
            );


            $this->session->set_flashdata(
                'success',
                'Welcome back, ' . $user->first_name . '!'
            );


            redirect($user->role === 'admin' ? 'admin/dashboard' : 'student/dashboard');
        }


        $data['first_admin_setup_available'] =
            $this->User_Model->count_admin_accounts() === 0;
        $this->load->view('auth/login', $data);
    }

    public function setup_admin()
    {
        if ($this->session->userdata('logged_in')) {
            redirect(
                $this->session->userdata('role') === 'admin'
                    ? 'admin/dashboard'
                    : 'student/dashboard'
            );
        }

        if ($this->User_Model->count_admin_accounts() > 0) {
            $this->session->set_flashdata(
                'error',
                'Administrator setup is closed because an administrator account already exists.'
            );
            redirect('login');
        }

        $data = array('error' => '');

        if ($this->input->method(TRUE) === 'POST') {
            $this->form_validation->set_rules(
                'admin_id',
                'Admin ID',
                'required|trim|alpha_dash|min_length[3]|max_length[50]|is_unique[users.student_id]',
                array('is_unique' => 'Admin ID is already in use.')
            );
            $this->form_validation->set_rules(
                'first_name',
                'First Name',
                'required|trim|min_length[2]|max_length[100]'
            );
            $this->form_validation->set_rules(
                'last_name',
                'Last Name',
                'required|trim|min_length[2]|max_length[100]'
            );
            $this->form_validation->set_rules(
                'email',
                'Email',
                'required|trim|valid_email|max_length[150]|is_unique[users.email]',
                array('is_unique' => 'Email address is already in use.')
            );
            $this->form_validation->set_rules(
                'password',
                'Password',
                'required|min_length[8]|max_length[72]|callback_max_bytes'
            );
            $this->form_validation->set_rules(
                'confirm_password',
                'Confirm Password',
                'required|matches[password]'
            );

            $this->form_validation->set_message('max_bytes', 'Passwords must not exceed 72 bytes.');

            if (!$this->form_validation->run()) {
                $data['error'] = strip_tags(validation_errors(' '));
            } else {
                $admin_id = $this->input->post('admin_id', TRUE);
                $email = $this->input->post('email', TRUE);

                if ($this->User_Model->count_admin_accounts() > 0) {
                    $data['error'] = 'Administrator setup is closed because an administrator account already exists.';
                } else {
                    $created = $this->User_Model->create_user(array(
                        'student_id' => $admin_id,
                        'first_name' => $this->input->post('first_name', TRUE),
                        'last_name' => $this->input->post('last_name', TRUE),
                        'email' => $email,
                        'password' => password_hash(
                            $this->input->post('password'),
                            PASSWORD_DEFAULT
                        ),
                        'role' => 'admin'
                    ));

                    if ($created) {
                        $this->session->set_flashdata(
                            'success',
                            'Administrator account created. You can now sign in.'
                        );
                        redirect('login');
                    }

                    $data['error'] = 'Administrator account could not be created. Please try again.';
                }
            }

            if ($this->User_Model->count_admin_accounts() > 0) {
                $this->session->set_flashdata(
                    'error',
                    'Administrator setup is closed because an administrator account already exists.'
                );
                redirect('login');
            }
        }

        $this->load->view('auth/admin_setup', $data);
    }


  //log out

    public function logout()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            redirect('home');
        }

        $this->session->unset_userdata(array(
            'user_id',
            'student_id',
            'first_name',
            'last_name',
            'email',
            'role',
            'logged_in'
        ));
        $this->session->sess_destroy();

        $this->load->view('auth/logout');
    }

} 