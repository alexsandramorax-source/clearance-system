<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StudentController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        $this->load->model('User_Model');
        $this->load->model('Student_Model');
        $this->load->model('Clearance_Model');
    }


    private function check_login()
    {

        if (!$this->session->userdata('logged_in')) {

            $this->session->set_flashdata(
                'error',
                'Please login first.'
            );

            redirect('login');
        }


        if ($this->session->userdata('role') != 'student') {

            redirect('home');
        }

        if ($this->session->userdata('profile_photo') === NULL) {
            $student = $this->Student_Model->get_by_user_id(
                $this->session->userdata('user_id')
            );
            $this->session->set_userdata(
                'profile_photo',
                $student ? $student->profile_photo : ''
            );
        }
    }


    public function index()
    {

        $this->check_login();


        $user_id =
            $this->session->userdata('user_id');


        $data['user'] =
            $this->User_Model->get_by_id($user_id);


        $data['student'] =
            $this->Student_Model->get_by_user_id($user_id);

        $data['requirements'] =
            $this->Clearance_Model->get_requirements();


        $this->load->view(
            'student/dashboard',
            $data
        );
    }


    public function profile()
    {

        $this->check_login();


        $user_id =
            $this->session->userdata('user_id');


        $data['user'] =
            $this->User_Model->get_by_id($user_id);


        $data['student'] =
            $this->Student_Model->get_by_user_id($user_id);

        if (!$data['user'] || !$data['student']) {
            $this->session->set_flashdata(
                'error',
                'Student profile information was not found.'
            );
            redirect('student/dashboard');
        }

        $this->load->view(
            'student/profile',
            $data
        );
    }

    public function edit_profile()
    {
        $this->check_login();

        $user_id = $this->session->userdata('user_id');
        $data['user'] = $this->User_Model->get_by_id($user_id);
        $data['student'] = $this->Student_Model->get_by_user_id($user_id);

        if (!$data['user'] || !$data['student']) {
            $this->session->set_flashdata('error', 'Student profile information was not found.');
            redirect('student/dashboard');
        }

        $this->load->view('student/update', $data);
    }


    public function update_profile()
    {

        $this->check_login();
        if ($this->input->method(TRUE) !== 'POST') {
            redirect('student/profile/edit');
        }

        $user_id = $this->session->userdata('user_id');
        $user = $this->User_Model->get_by_id($user_id);

        $student =
            $this->Student_Model->get_by_user_id(
                $user_id
            );

        if (!$user || !$student) {
            $this->session->set_flashdata(
                'error',
                'Student profile information was not found.'
            );

            redirect('student/profile/edit');
        }

        $this->form_validation->set_rules(
            'student_id',
            'Student ID',
            'required|trim|regex_match[/^[0-9]{3,50}$/]|callback_unique_profile_student_id',
            array('regex_match' => 'Student ID must be numbers.')
        );

        $this->form_validation->set_rules(
            'first_name',
            'First Name',
            'required|trim|min_length[2]|max_length[100]'
        );

        $this->form_validation->set_rules(
            'last_name',
            'Last Name',
            'required|trim|min_length[2]|max_length[100]'
        );

        $this->form_validation->set_rules(
            'email',
            'Email',
            'required|trim|regex_match[/^[^@\s]+@[^@\s]+$/]|valid_email|max_length[150]|callback_unique_profile_email',
            array('regex_match' => 'Email must contain @.')
        );

        $this->form_validation->set_rules(
            'course',
            'Course',
            'required|trim|max_length[150]'
        );

        $this->form_validation->set_rules(
            'year_level',
            'Year Level',
            'required|trim|in_list[1st Year,2nd Year,3rd Year,4th Year]'
        );

        $this->form_validation->set_rules(
            'contact_number',
            'Contact Number',
            'required|trim|regex_match[/^[0-9+() -]{7,30}$/]'
        );

        $this->form_validation->set_rules(
            'address',
            'Address',
            'required|trim|max_length[255]'
        );

        $this->form_validation->set_message(
            'unique_profile_student_id',
            'Student ID is already in use.'
        );
        $this->form_validation->set_message(
            'unique_profile_email',
            'Email address is already in use.'
        );

        if ($this->form_validation->run() == FALSE) {

            $this->session->set_flashdata(
                'error',
                validation_errors(' ', ' ')
            );

            redirect('student/profile/edit');
        }

        $student_id = $this->form_validation->set_value('student_id');
        $email = $this->form_validation->set_value('email');

        $user_data = array(
            'student_id' => $student_id,
            'first_name' => $this->form_validation->set_value('first_name'),
            'last_name' => $this->form_validation->set_value('last_name'),
            'email' => $email
        );

        $student_data = array(
            'student_id' => $student_id,
            'course' => $this->form_validation->set_value('course'),
            'year_level' => $this->form_validation->set_value('year_level'),
            'contact_number' => $this->form_validation->set_value('contact_number'),
            'address' => $this->form_validation->set_value('address')
        );

        $this->db->trans_start();
        $user_updated = $this->User_Model->update_user($user_id, $user_data);
        $student_updated = $this->Student_Model->update_student($student->id, $student_data);
        $this->db->trans_complete();

        if ($user_updated && $student_updated && $this->db->trans_status() !== FALSE) {
            $this->session->set_userdata(array(
                'student_id' => $student_id,
                'first_name' => $user_data['first_name'],
                'last_name' => $user_data['last_name'],
                'email' => $email
            ));

            $this->session->set_flashdata(
                'success',
                'Profile updated successfully.'
            );

        } else {

            log_message('error', 'Student profile update failed: ' . json_encode($this->db->error()));
            $this->session->set_flashdata(
                'error',
                'Failed to update profile. Please try again.'
            );
            redirect('student/profile/edit');
        }


        redirect('student/profile');
    }

    public function unique_profile_student_id($student_id)
    {
        if (!is_string($student_id) || $student_id === '') {
            return FALSE;
        }

        $existing_user = $this->User_Model->get_by_student_id($student_id);
        return !$existing_user
            || (int) $existing_user->id === (int) $this->session->userdata('user_id');
    }

    public function unique_profile_email($email)
    {
        if (!is_string($email) || $email === '') {
            return FALSE;
        }

        $existing_user = $this->User_Model->get_by_email($email);
        return !$existing_user
            || (int) $existing_user->id === (int) $this->session->userdata('user_id');
    }

    public function upload_profile_photo()
    {
        $this->check_login();
        if ($this->input->method(TRUE) !== 'POST') {
            redirect('student/profile/edit');
        }

        $student = $this->Student_Model->get_by_user_id(
            $this->session->userdata('user_id')
        );

        if (!$student) {
            $this->session->set_flashdata('error', 'Student profile information was not found.');
            redirect('student/profile/edit');
        }

        $this->load->library('fileuploader');
        $upload = $this->fileuploader->upload_profile_image(
            'profile_photo',
            'assets/uploads/profiles'
        );

        if (empty($upload['success'])) {
            $this->session->set_flashdata('error', $upload['message']);
            redirect('student/profile/edit');
        }

        if (!$this->Student_Model->update_student($student->id, array(
            'profile_photo' => $upload['path']
        ))) {
            if (is_file($upload['full_path']) && !unlink($upload['full_path'])) {
                log_message('error', 'Could not remove an unreferenced profile image after a database update failed.');
            }
            $this->session->set_flashdata('error', 'The profile photo could not be saved. Please try again.');
            redirect('student/profile/edit');
        }

        $this->session->set_userdata('profile_photo', $upload['path']);

        if (!empty($student->profile_photo)
            && preg_match('#^assets/uploads/profiles/[a-f0-9]{32}\.(jpg|png|webp)$#', $student->profile_photo)) {
            $old_photo = FCPATH . str_replace('/', DIRECTORY_SEPARATOR, $student->profile_photo);
            if (is_file($old_photo) && !unlink($old_photo)) {
                log_message('error', 'Could not remove a replaced profile image: ' . $student->profile_photo);
            }
        }

        $this->session->set_flashdata('success', 'Profile photo updated successfully.');
        redirect('student/profile/edit');
    }

}