<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student_Model extends CI_Model
{

    public function create_student($data)
    {
        return $this->db->insert('students', $data);
    }


    public function get_by_user_id($user_id)
    {
        return $this->db
            ->where('user_id', $user_id)
            ->get('students')
            ->row();
    }


    public function get_by_id($id)
    {
        return $this->db
            ->where('id', $id)
            ->get('students')
            ->row();
    }

    public function get_student_export_rows()
    {
        return $this->db
            ->select("
                users.student_id,
                users.first_name,
                users.last_name,
                users.email,
                '' AS password,
                students.course,
                students.year_level,
                students.contact_number,
                students.address
            ", FALSE)
            ->from('students')
            ->join('users', 'users.id = students.user_id')
            ->where('users.role', 'student')
            ->order_by('users.student_id', 'ASC')
            ->get()
            ->result_array();
    }

    public function count_student_accounts()
    {
        return (int) $this->db
            ->join('users', 'users.id = students.user_id')
            ->where('users.role', 'student')
            ->count_all_results('students');
    }

    public function get_recent_student_accounts($limit = 100)
    {
        $limit = max(1, min(500, (int) $limit));

        return $this->db
            ->select('
                users.student_id,
                users.first_name,
                users.last_name,
                users.email,
                users.created_at,
                students.course,
                students.year_level,
                students.contact_number,
                students.address
            ')
            ->from('students')
            ->join('users', 'users.id = students.user_id')
            ->where('users.role', 'student')
            ->order_by('users.created_at', 'DESC')
            ->order_by('users.id', 'DESC')
            ->limit($limit)
            ->get()
            ->result();
    }

    public function get_student_email_recipients()
    {
        $recipients = $this->db
            ->select('
                users.id,
                users.student_id,
                users.first_name,
                users.last_name,
                users.email
            ')
            ->from('students')
            ->join('users', 'users.id = students.user_id')
            ->where('users.role', 'student')
            ->order_by('users.last_name', 'ASC')
            ->order_by('users.first_name', 'ASC')
            ->get()
            ->result();

        return array_values(array_filter($recipients, function ($recipient) {
            return filter_var($recipient->email, FILTER_VALIDATE_EMAIL) !== FALSE;
        }));
    }


    public function update_student($id, $data)
    {
        return $this->db
            ->where('id', $id)
            ->update('students', $data);
    }

}