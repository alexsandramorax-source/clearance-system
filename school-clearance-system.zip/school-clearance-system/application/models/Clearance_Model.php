<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clearance_Model extends CI_Model
{

    
    // GET ALL CLEARANCE REQUIREMENTS
    
    public function get_requirements()
    {
        return $this->db
            ->select('
                clearance_requirements.*,
                departments.department_name
            ')
            ->from('clearance_requirements')
            ->join(
                'departments',
                'departments.id = clearance_requirements.department_id'
            )
            ->order_by(
                'departments.department_name',
                'ASC'
            )
            ->get()
            ->result();
    }


   
    // CREATE CLEARANCE REQUEST
    

    public function create_request($data)
    {
        return $this->db->insert(
            'clearance_requests',
            $data
        );
    }


   
    // GET STUDENT CLEARANCE REQUESTS
    

    public function get_student_requests($student_id)
    {
        return $this->db
            ->where(
                'student_id',
                $student_id
            )
            ->order_by(
                'created_at',
                'DESC'
            )
            ->get('clearance_requests')
            ->result();
    }


   
    // GET SINGLE REQUEST
 

    public function get_request(
        $request_id,
        $student_id
    )
    {
        return $this->db
            ->where('id', $request_id)
            ->where(
                'student_id',
                $student_id
            )
            ->get('clearance_requests')
            ->row();
    }


    
    // DELETE REQUEST
    
    public function delete_request(
        $request_id,
        $student_id
    )
    {
        return $this->db
            ->where('id', $request_id)
            ->where(
                'student_id',
                $student_id
            )
            ->delete('clearance_requests');
    }

    
    // UPDATE CLEARANCE REQUEST
   

public function update_request($request_id, $student_id, $data)
{
    return $this->db
        ->where('id', $request_id)
        ->where('student_id', $student_id)
        ->where('status', 'Pending')
        ->update(
            'clearance_requests',
            $data
        );
}


    
    // GET CLEARANCE STATUS
   

    public function get_status(
        $request_id
    )
    {
        return $this->db
            ->select('
                clearance_status.*,
                departments.department_name
            ')
            ->from('clearance_status')
            ->join(
                'departments',
                'departments.id = clearance_status.department_id'
            )
            ->where(
                'clearance_status.clearance_request_id',
                $request_id
            )
            ->order_by(
                'departments.department_name',
                'ASC'
            )
            ->get()
            ->result();
    }


    
    // GET LATEST REQUEST
   
    public function get_latest_request(
        $student_id
    )
    {
        return $this->db
            ->where(
                'student_id',
                $student_id
            )
            ->order_by(
                'created_at',
                'DESC'
            )
            ->limit(1)
            ->get('clearance_requests')
            ->row();
    }


   
    // GET DEPARTMENTS
   

    public function get_departments()
    {
        return $this->db
            ->order_by(
                'department_name',
                'ASC'
            )
            ->get('departments')
            ->result();
    }


  
    // CREATE STATUS FOR EACH DEPARTMENT
  

    public function create_department_status(
        $request_id,
        $department_id
    )
    {
        $data = array(

            'clearance_request_id' =>
                $request_id,

            'department_id' =>
                $department_id,

            'status' =>
                'Pending',

            'remarks' =>
                NULL

        );

        return $this->db->insert(
            'clearance_status',
            $data
        );
    }

}