<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Model extends CI_Model
{
    public function get_requests()
    {
        return $this->db
            ->select('
                clearance_requests.*,
                students.student_id,
                users.first_name,
                users.last_name
            ')
            ->from('clearance_requests')
            ->join('students', 'students.id = clearance_requests.student_id')
            ->join('users', 'users.id = students.user_id')
            ->order_by('clearance_requests.created_at', 'DESC')
            ->get()
            ->result();
    }

    public function get_status_counts()
    {
        $rows = $this->db
            ->select('status, COUNT(*) AS total')
            ->group_by('status')
            ->get('clearance_requests')
            ->result();

        $counts = array(
            'Pending' => 0,
            'Processing' => 0,
            'Cleared' => 0,
            'Rejected' => 0
        );

        foreach ($rows as $row) {
            if (array_key_exists($row->status, $counts)) {
                $counts[$row->status] = (int) $row->total;
            }
        }

        return $counts;
    }

    public function update_request($request_id, $status, $remarks)
    {
        return $this->db
            ->where('id', $request_id)
            ->update('clearance_requests', array(
                'status' => $status,
                'remarks' => $remarks
            ));
    }
}
