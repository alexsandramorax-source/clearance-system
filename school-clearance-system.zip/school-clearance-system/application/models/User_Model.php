<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_Model extends CI_Model
{

    public function create_user($data)
    {
        return $this->db->insert('users', $data);
    }


    public function get_by_email($email)
    {
        return $this->db
            ->where('email', $email)
            ->get('users')
            ->row();
    }


    public function get_by_student_id($student_id)
    {
        return $this->db
            ->where('student_id', $student_id)
            ->get('users')
            ->row();
    }


    public function get_by_id($id)
    {
        return $this->db
            ->where('id', $id)
            ->get('users')
            ->row();
    }

    public function count_admin_accounts()
    {
        return (int) $this->db
            ->where('role', 'admin')
            ->count_all_results('users');
    }


    public function update_user($id, $data)
    {
        return $this->db
            ->where('id', $id)
            ->update('users', $data);
    }

}