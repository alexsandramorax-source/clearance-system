<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class StudentSpreadsheetExporter
{
    public function write_xlsx($path, $headers, $rows)
    {
        if (!class_exists(Spreadsheet::class)) {
            return array(
                'success' => FALSE,
                'message' => 'Excel export requires PhpSpreadsheet. Run composer install in the project directory.'
            );
        }

        $spreadsheet = new Spreadsheet();
        $worksheet = $spreadsheet->getActiveSheet();
        $worksheet->setTitle('Students');

        foreach (array_merge(array($headers), $rows) as $row_index => $row) {
            foreach (array_values($row) as $column_index => $value) {
                $cell = Coordinate::stringFromColumnIndex($column_index + 1)
                    . ($row_index + 1);
                $worksheet->setCellValueExplicit(
                    $cell,
                    (string) $value,
                    DataType::TYPE_STRING
                );
            }
        }

        $worksheet->freezePane('A2');
        $worksheet->setAutoFilter(
            'A1:' . Coordinate::stringFromColumnIndex(count($headers))
            . max(1, count($rows) + 1)
        );

        try {
            (new Xlsx($spreadsheet))->save($path);
        } catch (Throwable $exception) {
            log_message(
                'error',
                'Student XLSX export failed: ' . $exception->getMessage()
            );
            $spreadsheet->disconnectWorksheets();
            return array(
                'success' => FALSE,
                'message' => 'The Excel workbook could not be created.'
            );
        }

        $spreadsheet->disconnectWorksheets();
        return array('success' => TRUE);
    }
}
