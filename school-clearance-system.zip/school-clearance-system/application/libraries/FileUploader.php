<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FileUploader
{
    private $ci;

    public function __construct()
    {
        $this->ci =& get_instance();
    }

    public function upload_profile_image($field, $relative_directory)
    {
        if (empty($_FILES[$field]) || !is_uploaded_file($_FILES[$field]['tmp_name'])) {
            return array('success' => FALSE, 'message' => 'Choose an image to upload.');
        }

        $file = $_FILES[$field];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return array('success' => FALSE, 'message' => $this->upload_error_message($file['error']));
        }

        if ($file['size'] > 2 * 1024 * 1024) {
            return array('success' => FALSE, 'message' => 'Profile images must be 2 MB or smaller.');
        }

        $image = @getimagesize($file['tmp_name']);
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($file['tmp_name']);
        $allowed = array(
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp'
        );

        if (!$image || !isset($allowed[$mime]) || $image['mime'] !== $mime) {
            return array('success' => FALSE, 'message' => 'Choose a valid JPG, PNG, or WebP image.');
        }

        if ($image[0] > 2000 || $image[1] > 2000) {
            return array('success' => FALSE, 'message' => 'Profile images must not exceed 2000 pixels in either dimension.');
        }

        $directory = $this->ensure_directory($relative_directory);
        if ($directory === FALSE) {
            return array('success' => FALSE, 'message' => 'The profile image directory is unavailable.');
        }

        $filename = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
        $config = array(
            'upload_path' => $directory,
            'allowed_types' => 'jpg|jpeg|png|webp',
            'file_name' => $filename,
            'overwrite' => FALSE,
            'max_size' => 2048,
            'max_width' => 2000,
            'max_height' => 2000,
            'detect_mime' => TRUE,
            'mod_mime_fix' => TRUE
        );

        $this->ci->load->library('upload');
        $this->ci->upload->initialize($config, TRUE);
        if (!$this->ci->upload->do_upload($field)) {
            return array(
                'success' => FALSE,
                'message' => strip_tags($this->ci->upload->display_errors('', ''))
            );
        }

        return array(
            'success' => TRUE,
            'filename' => $filename,
            'path' => trim(str_replace('\\', '/', $relative_directory), '/') . '/' . $filename,
            'full_path' => $directory . DIRECTORY_SEPARATOR . $filename
        );
    }

    public function upload_spreadsheet($field)
    {
        if (empty($_FILES[$field]) || !is_uploaded_file($_FILES[$field]['tmp_name'])) {
            return array('success' => FALSE, 'message' => 'Choose an XLSX or CSV file to upload.');
        }

        $extension = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, array('xlsx', 'csv'), TRUE)) {
            return array('success' => FALSE, 'message' => 'Only XLSX and CSV spreadsheets are accepted.');
        }

        $directory = APPPATH . 'cache' . DIRECTORY_SEPARATOR . 'uploads';
        if (!$this->make_directory($directory)) {
            return array('success' => FALSE, 'message' => 'The private upload directory is unavailable.');
        }

        $config = array(
            'upload_path' => $directory,
            'allowed_types' => 'xlsx|csv',
            'file_name' => bin2hex(random_bytes(16)) . '.' . $extension,
            'overwrite' => FALSE,
            'max_size' => 10240,
            'detect_mime' => TRUE,
            'mod_mime_fix' => TRUE
        );

        $this->ci->load->library('upload');
        $this->ci->upload->initialize($config, TRUE);
        if (!$this->ci->upload->do_upload($field)) {
            return array(
                'success' => FALSE,
                'message' => strip_tags($this->ci->upload->display_errors('', ''))
            );
        }

        $upload = $this->ci->upload->data();
        return array(
            'success' => TRUE,
            'full_path' => $upload['full_path'],
            'extension' => $extension
        );
    }

    public function upload_email_attachment($field)
    {
        if (empty($_FILES[$field])
            || !is_array($_FILES[$field])
            || !isset($_FILES[$field]['error'], $_FILES[$field]['name'], $_FILES[$field]['tmp_name'])) {
            return array('success' => FALSE, 'message' => 'Choose a file or send the email without an attachment.');
        }

        $file = $_FILES[$field];
        if (!is_scalar($file['error'])
            || !is_string($file['name'])
            || !is_string($file['tmp_name'])) {
            return array('success' => FALSE, 'message' => 'The selected attachment is invalid.');
        }

        if ((int) $file['error'] === UPLOAD_ERR_NO_FILE) {
            return array('success' => TRUE, 'path' => NULL);
        }

        if ((int) $file['error'] !== UPLOAD_ERR_OK
            || !is_uploaded_file($file['tmp_name'])) {
            return array(
                'success' => FALSE,
                'message' => $this->upload_error_message((int) $file['error'])
            );
        }

        $extension = strtolower(pathinfo((string) $file['name'], PATHINFO_EXTENSION));
        $allowed_extensions = array(
            'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'txt', 'jpg', 'jpeg', 'png'
        );
        if (!in_array($extension, $allowed_extensions, TRUE)) {
            return array(
                'success' => FALSE,
                'message' => 'Attachments must be PDF, Word, Excel, CSV, TXT, JPG, or PNG files.'
            );
        }

        $directory = APPPATH . 'cache' . DIRECTORY_SEPARATOR . 'email_attachments';
        if (!$this->make_directory($directory)) {
            return array(
                'success' => FALSE,
                'message' => 'The private email attachment directory is unavailable.'
            );
        }

        $filename = bin2hex(random_bytes(16)) . '.' . $extension;
        $config = array(
            'upload_path' => $directory,
            'allowed_types' => implode('|', $allowed_extensions),
            'file_name' => $filename,
            'overwrite' => FALSE,
            'max_size' => 10240,
            'max_filename' => 100,
            'detect_mime' => TRUE,
            'mod_mime_fix' => TRUE
        );

        $this->ci->load->library('upload');
        $this->ci->upload->initialize($config, TRUE);
        if (!$this->ci->upload->do_upload($field)) {
            return array(
                'success' => FALSE,
                'message' => strip_tags($this->ci->upload->display_errors('', ''))
            );
        }

        $upload = $this->ci->upload->data();
        return array(
            'success' => TRUE,
            'path' => $upload['full_path']
        );
    }

    private function ensure_directory($relative_directory)
    {
        $relative_directory = trim(str_replace('\\', '/', $relative_directory), '/');
        if ($relative_directory === '' || strpos($relative_directory, '..') !== FALSE) {
            return FALSE;
        }

        $directory = rtrim(FCPATH, '\\/') . DIRECTORY_SEPARATOR
            . str_replace('/', DIRECTORY_SEPARATOR, $relative_directory);
        return $this->make_directory($directory) ? $directory : FALSE;
    }

    private function make_directory($directory)
    {
        if (is_dir($directory)) {
            return is_writable($directory);
        }

        if (!@mkdir($directory, 0755, TRUE) && !is_dir($directory)) {
            return FALSE;
        }

        return is_writable($directory);
    }

    private function upload_error_message($error)
    {
        $messages = array(
            UPLOAD_ERR_INI_SIZE => 'The selected file exceeds the server upload limit.',
            UPLOAD_ERR_FORM_SIZE => 'The selected file exceeds the form upload limit.',
            UPLOAD_ERR_PARTIAL => 'The file upload was incomplete. Please try again.',
            UPLOAD_ERR_NO_FILE => 'Choose a file to upload.',
            UPLOAD_ERR_NO_TMP_DIR => 'The server upload temporary directory is unavailable.',
            UPLOAD_ERR_CANT_WRITE => 'The server could not save the uploaded file.',
            UPLOAD_ERR_EXTENSION => 'The server rejected the uploaded file.'
        );

        return isset($messages[$error]) ? $messages[$error] : 'The file upload failed.';
    }
}
