<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\IOFactory;

class StudentSpreadsheetImporter
{
    private $required_columns = array(
        'student_id',
        'first_name',
        'last_name',
        'email',
        'password',
        'course',
        'year_level',
        'contact_number',
        'address'
    );

    public function read($path, $extension)
    {
        if (!class_exists(IOFactory::class)) {
            return $this->failure(
                'Spreadsheet import requires PhpSpreadsheet. Run composer install in the project directory.'
            );
        }

        $reader_type = strtolower($extension) === 'xlsx' ? 'Xlsx' : 'Csv';
        if (!in_array(strtolower($extension), array('xlsx', 'csv'), TRUE)) {
            return $this->failure('Only XLSX and CSV spreadsheets are supported.');
        }

        if ($reader_type === 'Xlsx') {
            $archive_error = $this->validate_xlsx_archive($path);
            if ($archive_error !== NULL) {
                return $this->failure($archive_error);
            }
        }

        try {
            $reader = IOFactory::createReader($reader_type);
            $reader->setReadDataOnly(TRUE);
            if ($reader_type === 'Csv') {
                $reader->setDelimiter(',');
                $reader->setEnclosure('"');
                $reader->setInputEncoding('UTF-8');
            }

            if ($reader_type === 'Xlsx') {
                $worksheet_names = $reader->listWorksheetNames($path);
                if (empty($worksheet_names)) {
                    return $this->failure('The spreadsheet does not contain a worksheet.');
                }
                $reader->setLoadSheetsOnly($worksheet_names[0]);
            }

            $spreadsheet = $reader->load($path);
            $worksheet = $spreadsheet->getSheet(0);
            $highest_row = $worksheet->getHighestDataRow();
            $highest_column = Coordinate::columnIndexFromString(
                $worksheet->getHighestDataColumn()
            );

            if ($highest_row > 1001) {
                $spreadsheet->disconnectWorksheets();
                return $this->failure('A spreadsheet can contain at most 1000 student rows.');
            }

            if ($highest_column > count($this->required_columns)) {
                $spreadsheet->disconnectWorksheets();
                return $this->failure('The spreadsheet contains extra columns.');
            }

            for ($row = 1; $row <= $highest_row; $row++) {
                for ($column = 1; $column <= $highest_column; $column++) {
                    if ($worksheet->getCell(
                        Coordinate::stringFromColumnIndex($column) . $row
                    )->getDataType() === DataType::TYPE_FORMULA) {
                        $spreadsheet->disconnectWorksheets();
                        return $this->failure(
                            'Formula cells are not allowed in the student import spreadsheet.'
                        );
                    }
                }
            }

            $records = $worksheet->rangeToArray(
                'A1:' . Coordinate::stringFromColumnIndex(
                    count($this->required_columns)
                ) . $highest_row,
                NULL,
                FALSE,
                FALSE,
                FALSE
            );
            $spreadsheet->disconnectWorksheets();

            return $this->normalize_records($records);
        } catch (Throwable $exception) {
            log_message(
                'error',
                'Student spreadsheet processing failed: ' . $exception->getMessage()
            );
            return $this->failure(
                'The spreadsheet could not be read. Check that it is a valid XLSX or CSV file.'
            );
        }
    }

    private function validate_xlsx_archive($path)
    {
        if (!class_exists('ZipArchive')) {
            return 'XLSX processing is unavailable because PHP ZIP support is not enabled.';
        }

        $archive = new ZipArchive();
        if ($archive->open($path) !== TRUE) {
            return 'The uploaded XLSX file is invalid or damaged.';
        }

        if ($archive->numFiles > 1000) {
            $archive->close();
            return 'The XLSX file contains too many archive entries.';
        }

        $expanded_size = 0;
        for ($index = 0; $index < $archive->numFiles; $index++) {
            $entry = $archive->statIndex($index);
            if ($entry === FALSE) {
                $archive->close();
                return 'The XLSX archive contains an unreadable file entry.';
            }

            $entry_name = str_replace('\\', '/', $entry['name']);
            if (strpos($entry_name, '/') === 0
                || preg_match('#(^|/)\.\.(/|$)#', $entry_name)) {
                $archive->close();
                return 'The XLSX archive contains an invalid file path.';
            }

            $expanded_size += (int) $entry['size'];
            if ($expanded_size > 25 * 1024 * 1024) {
                $archive->close();
                return 'The expanded XLSX workbook is too large to process.';
            }
        }

        $archive->close();
        return NULL;
    }

    private function normalize_records($records)
    {
        if (count($records) < 2) {
            return $this->failure('The spreadsheet must have a header row and at least one student row.');
        }

        $headers = array_shift($records);
        $normalized_headers = array();
        foreach ($headers as $index => $header) {
            $header = preg_replace('/^\xEF\xBB\xBF/', '', (string) $header);
            $header = strtolower(trim($header));
            $header = preg_replace('/[^a-z0-9]+/', '_', $header);
            $normalized_headers[$index] = trim($header, '_');
        }

        if (array_values($normalized_headers) !== $this->required_columns) {
            return $this->failure(
                'Use these columns in this exact order: '
                . implode(', ', $this->required_columns)
                . '.'
            );
        }

        $students = array();
        foreach ($records as $row_number => $row) {
            if (count(array_filter($row, function ($value) {
                return trim((string) $value) !== '';
            })) === 0) {
                continue;
            }

            if (count($row) > count($this->required_columns)) {
                return $this->failure('Row ' . ($row_number + 2) . ' contains extra columns.');
            }

            $row = array_pad(array_values($row), count($this->required_columns), '');
            $students[] = array_combine(
                $this->required_columns,
                array_map(function ($value) {
                    return trim((string) $value);
                }, $row)
            );
        }

        if (empty($students)) {
            return $this->failure('The spreadsheet does not contain any student rows.');
        }

        return array('success' => TRUE, 'students' => $students);
    }

    private function failure($message)
    {
        return array('success' => FALSE, 'message' => $message);
    }
}
