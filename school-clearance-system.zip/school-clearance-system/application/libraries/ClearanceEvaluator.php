<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ClearanceEvaluator
{
    public function evaluate($status)
    {
        if (!is_string($status)) {
            throw new InvalidArgumentException('Clearance status must be a string.');
        }

        switch ($status) {
            case 'Pending':
                return array(
                    'label' => 'Waiting for review',
                    'message' => 'Your request is waiting for a clearance administrator to review it.',
                    'tone' => 'info'
                );

            case 'Processing':
                return array(
                    'label' => 'Under review',
                    'message' => 'A clearance administrator is currently reviewing your request.',
                    'tone' => 'warning'
                );

            case 'Cleared':
                return array(
                    'label' => 'Clearance complete',
                    'message' => 'Your clearance request has been approved.',
                    'tone' => 'success'
                );

            case 'Rejected':
                return array(
                    'label' => 'Action needed',
                    'message' => 'Your request was not approved. Review the remarks and contact the clearance office.',
                    'tone' => 'danger'
                );

            default:
                throw new InvalidArgumentException('Unsupported clearance request status.');
        }
    }
}
