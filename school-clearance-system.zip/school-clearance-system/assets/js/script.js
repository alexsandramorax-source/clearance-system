document.addEventListener('DOMContentLoaded', function () {
    var menuToggle = document.querySelector('.app-menu-toggle');

    if (menuToggle) {
        menuToggle.addEventListener('click', function () {
            var isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', isExpanded ? 'false' : 'true');
            document.body.classList.toggle('sidebar-collapsed', isExpanded);
        });
    }

    var profileMenu = document.getElementById('student-profile-menu');
    if (profileMenu) {
        document.addEventListener('click', function (event) {
            if (!profileMenu.contains(event.target)) {
                profileMenu.open = false;
            }
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && profileMenu.open) {
                profileMenu.open = false;
                profileMenu.querySelector('summary').focus();
            }
        });
    }
});