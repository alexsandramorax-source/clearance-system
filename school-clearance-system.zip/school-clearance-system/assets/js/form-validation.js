(function () {
    function attachRequiredFieldValidation() {
        var forms = document.querySelectorAll('form');

        Array.prototype.forEach.call(forms, function (form) {
            form.noValidate = true;
            var inlineValidation = form.hasAttribute('data-inline-validation');
            var validationAttempted = !!form.querySelector('.server-validation-feedback');

            function showInlineError(field, message) {
                var feedback = field.nextElementSibling;
                if (!feedback || !feedback.classList.contains('inline-validation-feedback')) {
                    feedback = document.createElement('div');
                    feedback.className = 'invalid-feedback d-block inline-validation-feedback';
                    field.insertAdjacentElement('afterend', feedback);
                }

                field.classList.add('is-invalid');
                field.setAttribute('aria-invalid', 'true');
                feedback.textContent = message;
            }

            function clearInlineError(field) {
                var feedback = field.nextElementSibling;
                field.classList.remove('is-invalid');
                field.setAttribute('aria-invalid', 'false');
                if (feedback && feedback.classList.contains('inline-validation-feedback')) {
                    feedback.remove();
                }
            }

            function updateInlineFieldError(field) {
                if (field.validity.valid) {
                    clearInlineError(field);
                    return;
                }

                if (field.validity.valueMissing) {
                    if (validationAttempted) {
                        showInlineError(field, 'Please fill out the required fields.');
                    } else {
                        clearInlineError(field);
                    }
                    return;
                }

                if (field.value !== '') {
                    showInlineError(field, field.validationMessage);
                } else {
                    clearInlineError(field);
                }
            }

            var studentId = form.querySelector('[name="student_id"]');
            var email = form.querySelector('[name="email"]');

            if (studentId) {
                var validateStudentId = function () {
                    var message = studentId.value !== '' && !/^[0-9]+$/.test(studentId.value)
                        ? 'Student ID must be numbers.'
                        : '';
                    studentId.setCustomValidity(message);
                    if (inlineValidation) {
                        if (!message && studentId.validity.valid) {
                            clearInlineError(studentId);
                        }
                    }
                };
                studentId.addEventListener('input', validateStudentId);
                validateStudentId();
            }

            if (email) {
                var validateEmail = function () {
                    var message = email.value !== '' && email.value.indexOf('@') === -1
                        ? 'Email must contain @.'
                        : '';
                    email.setCustomValidity(message);
                    if (inlineValidation) {
                        if (!message && email.validity.valid) {
                            clearInlineError(email);
                        }
                    }
                };
                email.addEventListener('input', validateEmail);
                validateEmail();
            }

            if (inlineValidation) {
                Array.prototype.forEach.call(
                    form.querySelectorAll('input, select, textarea'),
                    function (field) {
                        if (field.type === 'hidden' || field.type === 'submit' || field.disabled) {
                            return;
                        }

                        field.addEventListener('input', function () {
                            if (validationAttempted) {
                                updateInlineFieldError(field);
                            }
                        });

                        field.addEventListener('change', function () {
                            if (validationAttempted) {
                                updateInlineFieldError(field);
                            }
                        });
                    }
                );
            }

            form.addEventListener('submit', function (event) {
                validationAttempted = true;
                if (form.checkValidity()) {
                    return;
                }

                event.preventDefault();

                var invalidFields = form.querySelectorAll(':invalid');
                var firstInvalidField = invalidFields.length ? invalidFields[0] : null;
                if (inlineValidation) {
                    Array.prototype.forEach.call(invalidFields, function (field) {
                        var message = field.validationMessage;
                        if (field.required && field.validity.valueMissing) {
                            message = 'Please fill out the required fields.';
                        } else if (field.validity.typeMismatch && field.type === 'email'
                            && field.value.indexOf('@') !== -1) {
                            message = 'Enter a valid email address.';
                        }
                        showInlineError(field, message);
                    });

                    if (firstInvalidField && !firstInvalidField.disabled) {
                        firstInvalidField.focus();
                    }
                    return;
                }

                var hasMissingRequiredField = Array.prototype.some.call(
                    invalidFields,
                    function (field) {
                        return field.required && field.validity.valueMissing;
                    }
                );
                var formatError = Array.prototype.map.call(
                    invalidFields,
                    function (field) {
                        return field.validity.customError ? field.validationMessage : '';
                    }
                ).filter(Boolean)[0];

                if (formatError) {
                    if (window.alertify) {
                        window.alertify.set('notifier', 'position', 'top-right');
                        window.alertify.error(formatError);
                    } else {
                        window.alert(formatError);
                    }
                } else if (hasMissingRequiredField) {
                    if (window.alertify) {
                        window.alertify.set('notifier', 'position', 'top-right');
                        window.alertify.error('Please fill out the required fields.');
                    } else {
                        window.alert('Please fill out the required fields.');
                    }
                } else {
                    form.reportValidity();
                }

                if (firstInvalidField && !firstInvalidField.disabled) {
                    firstInvalidField.focus();
                }
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', attachRequiredFieldValidation);
    } else {
        attachRequiredFieldValidation();
    }
}());
