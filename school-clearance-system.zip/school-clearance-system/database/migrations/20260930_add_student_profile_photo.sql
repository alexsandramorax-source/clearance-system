ALTER TABLE students
    ADD COLUMN profile_photo VARCHAR(255) NULL AFTER address;
